#!/usr/bin/env bash
# elia-connect.sh
# Launches Elia TUI. Model selection is fully automatic — the router
# classifies every prompt and picks devops-expert or devops-reasoner.
# Clients always connect to the same endpoint regardless of query type.
#
# Connection path:
#   Elia → HTTPS :443 → Nginx (mTLS) → Router :8080 → Ollama :11434
#
# Prerequisites:
#   podman
#   ~/certs/client.crt, ~/certs/client.key, ~/certs/ca.crt
#
# Usage:
#   chmod +x elia-connect.sh && ./elia-connect.sh

set -euo pipefail

PLATFORM_HOST="${PLATFORM_HOST:-ai-platform.internal}"
CERT_DIR="${CERT_DIR:-$HOME/certs}"
SESSION_DIR="${SESSION_DIR:-$HOME/.ai-sessions}"

die() { echo "ERROR: $*" >&2; exit 1; }

[[ -f "$CERT_DIR/client.crt" ]] || die "Missing $CERT_DIR/client.crt"
[[ -f "$CERT_DIR/client.key" ]] || die "Missing $CERT_DIR/client.key"
[[ -f "$CERT_DIR/ca.crt"    ]] || die "Missing $CERT_DIR/ca.crt"

mkdir -p "$SESSION_DIR"

echo "Checking https://${PLATFORM_HOST}/healthz ..."
curl --silent --fail --max-time 5 \
     --cacert  "$CERT_DIR/ca.crt"     \
     --cert    "$CERT_DIR/client.crt" \
     --key     "$CERT_DIR/client.key" \
     "https://${PLATFORM_HOST}/healthz" \
  && echo "OK" \
  || die "Platform unreachable — check ${PLATFORM_HOST}:443 and your certs."

# model is set to "auto" — the router rewrites it per request.
# The response header X-Routed-Model shows which model was actually used.
podman run --rm -it \
    --name elia-client \
    -e OLLAMA_HOST="https://${PLATFORM_HOST}/ollama/" \
    -e OLLAMA_MODEL="auto" \
    -e SSL_CERT_FILE="/certs/ca.crt" \
    -e REQUESTS_CA_BUNDLE="/certs/ca.crt" \
    -e OLLAMA_CLIENT_CERT="/certs/client.crt" \
    -e OLLAMA_CLIENT_KEY="/certs/client.key" \
    -v "${CERT_DIR}:/certs:ro,z" \
    -v "${SESSION_DIR}:/root/.local/share/elia:rw,z" \
    localhost:5000/elia:latest
