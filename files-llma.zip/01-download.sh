#!/usr/bin/env bash
# jumpbox/01-download.sh
# ─────────────────────────────────────────────────────────────────────────────
# Run this on the JUMPBOX (internet-connected, 4 core / 16 GB).
# Downloads every artifact needed for the AI server into ./bundle/
#
# What gets downloaded:
#   images/       — OCI container images as .tar files
#   models/       — Ollama model weights (GGUF blobs)
#   pip/          — Python wheel files for RAG processor and router
#   docs/         — Seed knowledge base (K8s, Docker, Podman, Helm docs)
#
# Prerequisites on jumpbox:
#   podman  >= 4.0
#   ollama  (CLI only — for pulling model weights)
#   python3 + pip
#   curl, scp
#
# Usage:
#   chmod +x 01-download.sh
#   ./01-download.sh
#   # Then run 02-bundle.sh to package everything
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

BUNDLE_DIR="$(pwd)/bundle"
IMAGES_DIR="$BUNDLE_DIR/images"
MODELS_DIR="$BUNDLE_DIR/models"
PIP_DIR="$BUNDLE_DIR/pip"
DOCS_DIR="$BUNDLE_DIR/docs"
BUILD_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

log()  { echo "[$(date +%H:%M:%S)] $*"; }
die()  { echo "ERROR: $*" >&2; exit 1; }
need() { command -v "$1" &>/dev/null || die "$1 not found — install it: $2"; }

# ── Pre-flight ─────────────────────────────────────────────────────────────
preflight() {
    need podman  "dnf install -y podman  OR  apt install -y podman"
    need ollama  "curl -fsSL https://ollama.com/install.sh | sh"
    need python3 "dnf install -y python3  OR  apt install -y python3"
    need pip3    "dnf install -y python3-pip  OR  apt install -y python3-pip"
    need curl    "dnf install -y curl  OR  apt install -y curl"

    mkdir -p "$IMAGES_DIR" "$MODELS_DIR" "$PIP_DIR" "$DOCS_DIR"
    log "Bundle directory: $BUNDLE_DIR"
    log "Pre-flight OK"
}

# ── Step 1: Pull and save container images ─────────────────────────────────
pull_images() {
    log "=== Step 1: Container images ==="

    declare -A IMAGES=(
        ["ollama.tar"]="docker.io/ollama/ollama:latest"
        ["chromadb.tar"]="docker.io/chromadb/chroma:latest"
        ["nginx.tar"]="docker.io/library/nginx:alpine"
        ["elia.tar"]="ghcr.io/darrenburns/elia:latest"
    )

    for filename in "${!IMAGES[@]}"; do
        image="${IMAGES[$filename]}"
        outfile="$IMAGES_DIR/$filename"
        if [[ -f "$outfile" ]]; then
            log "SKIP (exists): $filename"
            continue
        fi
        log "PULL: $image"
        podman pull "$image"
        log "SAVE: $filename"
        podman save --output "$outfile" "$image"
        log "  → $(du -sh "$outfile" | cut -f1)"
    done

    # ── Build and save custom images ────────────────────────────────────────
    log "BUILD: python-rag-processor"
    podman build -t localhost/python-rag-processor:latest "$BUILD_DIR/rag/"
    podman save --output "$IMAGES_DIR/python-rag-processor.tar" \
        localhost/python-rag-processor:latest
    log "  → $(du -sh "$IMAGES_DIR/python-rag-processor.tar" | cut -f1)"

    log "BUILD: ai-router"
    podman build -t localhost/ai-router:latest "$BUILD_DIR/router/"
    podman save --output "$IMAGES_DIR/ai-router.tar" \
        localhost/ai-router:latest
    log "  → $(du -sh "$IMAGES_DIR/ai-router.tar" | cut -f1)"

    log "Images complete. Total: $(du -sh "$IMAGES_DIR" | cut -f1)"
}

# ── Step 2: Pull Ollama model weights ──────────────────────────────────────
pull_models() {
    log "=== Step 2: Ollama model weights ==="
    log "WARNING: ~37 GB total download. This will take a while."

    # Start local Ollama with a custom home so weights go to our bundle dir
    export OLLAMA_MODELS="$MODELS_DIR"

    # Start ollama serve in background if not already running
    if ! curl -sf http://127.0.0.1:11434/api/version &>/dev/null; then
        log "Starting Ollama server..."
        OLLAMA_MODELS="$MODELS_DIR" ollama serve &
        OLLAMA_PID=$!
        sleep 5
        local i=0
        until curl -sf http://127.0.0.1:11434/api/version &>/dev/null; do
            sleep 2; ((i++))
            [[ $i -gt 30 ]] && die "Ollama did not start"
        done
    fi

    for model in "qwen2.5-coder:32b" "qwen3:32b" "nomic-embed-text"; do
        log "PULL model: $model"
        OLLAMA_MODELS="$MODELS_DIR" ollama pull "$model"
        log "  → done"
    done

    # Stop the background Ollama if we started it
    if [[ -n "${OLLAMA_PID:-}" ]]; then
        kill "$OLLAMA_PID" 2>/dev/null || true
    fi

    log "Models complete. Total: $(du -sh "$MODELS_DIR" | cut -f1)"
}

# ── Step 3: Download Python wheels (offline pip install on AI server) ──────
download_wheels() {
    log "=== Step 3: Python wheels ==="

    # RAG processor deps
    pip3 download \
        --dest "$PIP_DIR/rag" \
        --platform manylinux_2_28_x86_64 \
        --python-version 311 \
        --only-binary=:all: \
        chromadb==0.5.20 \
        httpx==0.27.0 \
        pypdf==4.3.1 \
        pyyaml==6.0.2

    # Router deps
    pip3 download \
        --dest "$PIP_DIR/router" \
        --platform manylinux_2_28_x86_64 \
        --python-version 311 \
        --only-binary=:all: \
        fastapi==0.115.0 \
        uvicorn==0.30.6 \
        httpx==0.27.0

    log "Wheels complete. Total: $(du -sh "$PIP_DIR" | cut -f1)"
}

# ── Step 4: Download seed documentation ───────────────────────────────────
download_docs() {
    log "=== Step 4: Seed knowledge base ==="
    chmod +x "$BUILD_DIR/knowledge-seed/fetch-docs.sh"
    "$BUILD_DIR/knowledge-seed/fetch-docs.sh" "$DOCS_DIR"
    log "Docs complete. $(find "$DOCS_DIR" -name '*.md' | wc -l) files, \
$(du -sh "$DOCS_DIR" | cut -f1)"
}

# ── Step 5: Copy project source into bundle ────────────────────────────────
copy_source() {
    log "=== Step 5: Project source ==="
    rsync -a --exclude='bundle/' --exclude='.git/' \
        "$BUILD_DIR/" "$BUNDLE_DIR/source/"
    log "Source copied to bundle/source/"
}

# ── Summary ────────────────────────────────────────────────────────────────
summary() {
    log ""
    log "═══════════════════════════════════════════"
    log "  Download complete"
    log "═══════════════════════════════════════════"
    log ""
    log "  Bundle contents:"
    du -sh "$BUNDLE_DIR"/*/  2>/dev/null | while read size dir; do
        log "    $size  $(basename "$dir")"
    done
    log ""
    log "  Total bundle size: $(du -sh "$BUNDLE_DIR" | cut -f1)"
    log ""
    log "  Next step: ./02-bundle.sh"
    log ""
}

# ── Main ───────────────────────────────────────────────────────────────────
preflight
pull_images
pull_models
download_wheels
download_docs
copy_source
summary
