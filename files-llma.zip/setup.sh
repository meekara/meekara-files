#!/usr/bin/env bash
# setup.sh — Airgapped AI Diagnostic Platform
#
# Usage:
#   ./setup.sh install              # full first-time setup
#   ./setup.sh install --docker     # install using Docker instead of Podman
#   ./setup.sh certs                # regenerate certificates only
#   ./setup.sh new-client <name>    # issue a new developer client cert
#   ./setup.sh pull-models          # pull / update Ollama models
#   ./setup.sh build-models         # (re)build custom Modelfiles
#   ./setup.sh seed-knowledge       # fetch seed docs (needs internet)
#   ./setup.sh up [--docker]        # start the platform
#   ./setup.sh down [--docker]      # stop the platform
#   ./setup.sh logs [--docker]      # tail all logs

set -euo pipefail

# ── Models ────────────────────────────────────────────────────────────────────
# 32B models are justified by the 152 GB Ollama RAM allocation.
# 7B/8B were undersized for production DevOps work — 32B gives dramatically
# better YAML generation, log analysis, and multi-step reasoning.

# Base weights — pulled from registry, used as FROM in Modelfiles
INFERENCE_BASE="qwen2.5-coder:32b"    # best open-source infra/code model
REASONING_BASE="qwen3:32b"            # thinking mode for RCA and diagnosis
EMBED_MODEL="nomic-embed-text"        # RAG embeddings

# Custom model names created by Modelfiles (what operators actually use)
DEVOPS_EXPERT_MODEL="devops-expert"
DEVOPS_REASONER_MODEL="devops-reasoner"

# ── Paths ─────────────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMPOSE_DIR="$SCRIPT_DIR/../compose"
CERT_DIR="$SCRIPT_DIR/../certs"
MODELFILE_DIR="$SCRIPT_DIR/../modelfiles"
KNOWLEDGE_SEED_DIR="$SCRIPT_DIR/../knowledge-seed"
KNOWLEDGE_DIR="/opt/ai-platform/knowledge-base"

BASE_FILE="$COMPOSE_DIR/compose.yml"
PODMAN_OVERRIDE="$COMPOSE_DIR/compose.override.podman.yml"

log() { echo "[$(date +%H:%M:%S)] $*"; }
die() { echo "ERROR: $*" >&2; exit 1; }
need() { command -v "$1" &>/dev/null || die "$1 not found — install it first"; }

# ── Detect runtime ────────────────────────────────────────────────────────────
USE_DOCKER=false
for arg in "$@"; do [[ "$arg" == "--docker" ]] && USE_DOCKER=true; done

container_cmd() { $USE_DOCKER && echo "docker" || echo "podman"; }

compose_cmd() {
    if $USE_DOCKER; then
        docker compose -f "$BASE_FILE" "$@"
    else
        podman-compose -f "$BASE_FILE" -f "$PODMAN_OVERRIDE" "$@"
    fi
}

# ── Pre-flight ────────────────────────────────────────────────────────────────
preflight() {
    if $USE_DOCKER; then
        need docker
        docker compose version &>/dev/null || die "docker compose plugin not found"
    else
        need podman
        need podman-compose
    fi
    need openssl
    log "Runtime: $(container_cmd) — pre-flight OK"
}

# ── Certificates ──────────────────────────────────────────────────────────────
gen_certs() {
    log "Generating CA, server cert, and default client cert..."
    mkdir -p "$CERT_DIR" && chmod 700 "$CERT_DIR"
    pushd "$CERT_DIR" >/dev/null

    openssl req -x509 -newkey rsa:4096 -nodes \
        -keyout ca.key -out ca.crt -days 3650 \
        -subj "/CN=AI-Platform CA/O=Ops/OU=Security"

    openssl req -newkey rsa:4096 -nodes -keyout server.key -out server.csr \
        -subj "/CN=ai-platform.internal/O=Ops"
    openssl x509 -req -in server.csr -CA ca.crt -CAkey ca.key \
        -CAcreateserial -out server.crt -days 1095 \
        -extfile <(printf "subjectAltName=DNS:ai-platform.internal,IP:127.0.0.1")

    openssl req -newkey rsa:4096 -nodes -keyout client.key -out client.csr \
        -subj "/CN=developer-01/O=Ops/OU=Platform"
    openssl x509 -req -in client.csr -CA ca.crt -CAkey ca.key \
        -CAcreateserial -out client.crt -days 365

    chmod 600 *.key && chmod 644 *.crt && rm -f *.csr *.srl
    popd >/dev/null
    log "Certs written to $CERT_DIR"
}

new_client() {
    local name="${1:-}"; [[ -z "$name" ]] && die "Usage: $0 new-client <username>"
    pushd "$CERT_DIR" >/dev/null
    openssl req -newkey rsa:4096 -nodes -keyout "${name}.key" -out "${name}.csr" \
        -subj "/CN=${name}/O=Ops/OU=Platform"
    openssl x509 -req -in "${name}.csr" -CA ca.crt -CAkey ca.key \
        -CAcreateserial -out "${name}.crt" -days 365
    rm -f "${name}.csr" && chmod 600 "${name}.key" && chmod 644 "${name}.crt"
    popd >/dev/null
    log "Issued: $CERT_DIR/${name}.crt + .key"
}

# ── Build images ─────────────────────────────────────────────────────────────
build_images() {
    log "Building python-rag-processor image..."
    "$(container_cmd)" build -t localhost:5000/python-rag-processor:latest \
        "$SCRIPT_DIR/../rag/"
    "$(container_cmd)" push localhost:5000/python-rag-processor:latest

    log "Building ai-router image..."
    "$(container_cmd)" build -t localhost:5000/ai-router:latest \
        "$SCRIPT_DIR/../router/"
    "$(container_cmd)" push localhost:5000/ai-router:latest
    log "Images pushed."
}

# ── Pull base Ollama models ───────────────────────────────────────────────────
pull_models() {
    log "Pulling base models (this will take a while — ~35 GB total)..."
    log "  $INFERENCE_BASE  (~18 GB  — DevOps/K8s code generation)"
    log "  $REASONING_BASE  (~18 GB  — thinking mode RCA and diagnosis)"
    log "  $EMBED_MODEL     (~274 MB — RAG embeddings)"

    local vol_flag
    if $USE_DOCKER; then
        vol_flag="-v ai-platform-ollama-models:/root/.ollama"
    else
        vol_flag="-v ai-platform-ollama-models:/root/.ollama:Z"
    fi

    "$(container_cmd)" run --rm -d --name ollama-setup \
        $vol_flag -p 11434:11434 \
        ollama/ollama:latest ollama serve

    local i=0
    until curl -sf http://127.0.0.1:11434/api/version &>/dev/null; do
        sleep 2; ((i++))
        [[ $i -gt 30 ]] && {
            "$(container_cmd)" stop ollama-setup
            die "Ollama did not start in time"
        }
    done

    "$(container_cmd)" exec ollama-setup ollama pull "$INFERENCE_BASE"
    "$(container_cmd)" exec ollama-setup ollama pull "$REASONING_BASE"
    "$(container_cmd)" exec ollama-setup ollama pull "$EMBED_MODEL"
    "$(container_cmd)" stop ollama-setup
    log "Base models pulled."
}

# ── Build custom Modelfiles ───────────────────────────────────────────────────
build_models() {
    log "Building custom models from Modelfiles..."
    log "  $DEVOPS_EXPERT_MODEL   (FROM $INFERENCE_BASE + DevOps system prompt)"
    log "  $DEVOPS_REASONER_MODEL (FROM $REASONING_BASE + thinking mode RCA prompt)"

    local vol_flag
    if $USE_DOCKER; then
        vol_flag="-v ai-platform-ollama-models:/root/.ollama"
    else
        vol_flag="-v ai-platform-ollama-models:/root/.ollama:Z"
    fi

    # Start Ollama temporarily to run `ollama create`
    "$(container_cmd)" run --rm -d --name ollama-build \
        $vol_flag -p 11434:11434 \
        -v "$MODELFILE_DIR":/modelfiles:ro \
        ollama/ollama:latest ollama serve

    local i=0
    until curl -sf http://127.0.0.1:11434/api/version &>/dev/null; do
        sleep 2; ((i++))
        [[ $i -gt 30 ]] && {
            "$(container_cmd)" stop ollama-build
            die "Ollama did not start in time"
        }
    done

    "$(container_cmd)" exec ollama-build \
        ollama create "$DEVOPS_EXPERT_MODEL" -f /modelfiles/Modelfile.devops-expert

    "$(container_cmd)" exec ollama-build \
        ollama create "$DEVOPS_REASONER_MODEL" -f /modelfiles/Modelfile.devops-reasoner

    "$(container_cmd)" stop ollama-build
    log "Custom models built:"
    log "  Use '$DEVOPS_EXPERT_MODEL'   for day-to-day K8s/Docker/Podman work"
    log "  Use '$DEVOPS_REASONER_MODEL' for complex RCA and incident diagnosis"
}

# ── Seed knowledge base ───────────────────────────────────────────────────────
seed_knowledge() {
    log "Fetching seed documentation (requires internet access)..."
    chmod +x "$KNOWLEDGE_SEED_DIR/fetch-docs.sh"
    "$KNOWLEDGE_SEED_DIR/fetch-docs.sh" "$KNOWLEDGE_DIR"
}

# ── Knowledge base dir ────────────────────────────────────────────────────────
make_knowledge_dir() {
    sudo mkdir -p "$KNOWLEDGE_DIR" && sudo chmod 1777 "$KNOWLEDGE_DIR"
    log "Knowledge base drop zone: $KNOWLEDGE_DIR"
}

# ── Compose wrappers ──────────────────────────────────────────────────────────
platform_up()   { KNOWLEDGE_BASE_DIR="$KNOWLEDGE_DIR" compose_cmd up -d; }
platform_down() { compose_cmd down; }
platform_logs() { compose_cmd logs -f; }

# ── Dispatch ──────────────────────────────────────────────────────────────────
CMD="${1:-install}"
case "$CMD" in
    install)
        preflight
        gen_certs
        make_knowledge_dir
        build_images
        pull_models
        build_models
        seed_knowledge
        platform_up
        log ""
        log "Platform up. Active models:"
        log "  devops-expert   → day-to-day K8s / Docker / Podman / YAML"
        log "  devops-reasoner → RCA, incident diagnosis, architecture"
        log ""
        log "Verify with:"
        log "  curl --cacert $CERT_DIR/ca.crt \\"
        log "       --cert   $CERT_DIR/client.crt \\"
        log "       --key    $CERT_DIR/client.key \\"
        log "       https://ai-platform.internal/healthz"
        ;;
    certs)          gen_certs ;;
    new-client)     new_client "${2:-}" ;;
    pull-models)    pull_models ;;
    build-models)   build_models ;;
    seed-knowledge) seed_knowledge ;;
    up)             platform_up ;;
    down)           platform_down ;;
    logs)           platform_logs ;;
    *)
        echo "Usage: $0 {install|certs|new-client <n>|pull-models|build-models|seed-knowledge|up|down|logs} [--docker]"
        exit 1 ;;
esac
