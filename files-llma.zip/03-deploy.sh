#!/usr/bin/env bash
# jumpbox/03-deploy.sh
# ─────────────────────────────────────────────────────────────────────────────
# Run on the AI SERVER (airgapped, 48 core / 196 GB).
# Extracts the bundle, loads all container images into a local registry,
# imports Ollama model weights, and starts the platform.
#
# Prerequisites on AI server:
#   podman >= 4.0
#   podman-compose >= 1.0
#   openssl
#   A local OCI registry — this script starts one temporarily if needed,
#   or uses an existing one at localhost:5000.
#
# Usage:
#   # Copy bundle to AI server first, then:
#   chmod +x 03-deploy.sh
#   ./03-deploy.sh /opt/ai-platform/transfer/bundle
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

BUNDLE_DIR="${1:-$(pwd)/bundle}"
REGISTRY="localhost:5000"
KNOWLEDGE_DIR="/opt/ai-platform/knowledge-base"
DEPLOY_DIR="/opt/ai-platform/app"

log()  { echo "[$(date +%H:%M:%S)] $*"; }
die()  { echo "ERROR: $*" >&2; exit 1; }
need() { command -v "$1" &>/dev/null || die "$1 not found — install: $2"; }

# ── Pre-flight ─────────────────────────────────────────────────────────────
preflight() {
    need podman        "dnf install -y podman"
    need podman-compose "pip3 install podman-compose"
    need openssl       "dnf install -y openssl"

    [[ -d "$BUNDLE_DIR" ]]          || die "Bundle dir not found: $BUNDLE_DIR"
    [[ -d "$BUNDLE_DIR/images" ]]   || die "images/ missing from bundle"
    [[ -d "$BUNDLE_DIR/models" ]]   || die "models/ missing from bundle"
    [[ -d "$BUNDLE_DIR/source" ]]   || die "source/ missing from bundle"

    log "Bundle: $BUNDLE_DIR"
    log "Pre-flight OK"
}

# ── Step 1: Start local registry ───────────────────────────────────────────
start_registry() {
    if curl -sf http://localhost:5000/v2/ &>/dev/null; then
        log "Registry already running at $REGISTRY"
        return
    fi

    log "Starting local OCI registry..."
    podman run -d \
        --name local-registry \
        --restart always \
        -p 5000:5000 \
        -v /opt/ai-platform/registry:/var/lib/registry:z \
        docker.io/library/registry:2

    sleep 3
    curl -sf http://localhost:5000/v2/ \
        || die "Registry did not start. Check: podman logs local-registry"
    log "Registry running at $REGISTRY"

    # Trust the local registry (insecure, localhost only)
    mkdir -p /etc/containers
    if ! grep -q "localhost:5000" /etc/containers/registries.conf 2>/dev/null; then
        cat >> /etc/containers/registries.conf << 'CONF'

[[registry]]
location = "localhost:5000"
insecure = true
CONF
        log "Added localhost:5000 as insecure registry"
    fi
}

# ── Step 2: Load container images ─────────────────────────────────────────
load_images() {
    log "=== Step 2: Loading container images ==="

    # Map: tar filename → registry tag
    declare -A IMAGE_MAP=(
        ["ollama.tar"]="ollama/ollama:latest"
        ["chromadb.tar"]="chromadb/chroma:latest"
        ["nginx.tar"]="nginx:alpine"
        ["elia.tar"]="elia:latest"
        ["python-rag-processor.tar"]="python-rag-processor:latest"
        ["ai-router.tar"]="ai-router:latest"
    )

    for tarfile in "${!IMAGE_MAP[@]}"; do
        tag="${IMAGE_MAP[$tarfile]}"
        tarpath="$BUNDLE_DIR/images/$tarfile"

        [[ -f "$tarpath" ]] || { log "WARN: missing $tarfile — skipping"; continue; }

        log "LOAD: $tarfile → $REGISTRY/$tag"
        podman load --input "$tarpath"

        # The loaded image has its original name — retag for local registry
        local original_tag
        # Extract original image name from tar
        original_tag=$(podman load --input "$tarpath" 2>&1 | grep "Loaded image" | awk '{print $NF}' || true)

        podman tag "${original_tag:-$tag}" "$REGISTRY/$tag"
        podman push "$REGISTRY/$tag"
        log "  → pushed to $REGISTRY/$tag"
    done

    log "All images loaded."
}

# ── Step 3: Import Ollama model weights ────────────────────────────────────
import_models() {
    log "=== Step 3: Importing Ollama model weights ==="

    # Create the named volume so weights persist correctly
    podman volume create ai-platform-ollama-models 2>/dev/null || true

    # Find where podman stores this volume on disk
    VOL_PATH=$(podman volume inspect ai-platform-ollama-models \
        --format '{{.Mountpoint}}')
    log "Ollama model volume: $VOL_PATH"

    # Copy the pre-downloaded model blobs directly into the volume
    log "Copying model weights (this may take a few minutes)..."
    sudo cp -a "$BUNDLE_DIR/models/." "$VOL_PATH/"
    sudo chown -R 0:0 "$VOL_PATH/"
    log "Model weights imported: $(du -sh "$VOL_PATH" | cut -f1)"
}

# ── Step 4: Copy seed docs to knowledge base ───────────────────────────────
import_docs() {
    log "=== Step 4: Importing seed knowledge base ==="
    sudo mkdir -p "$KNOWLEDGE_DIR"
    sudo chmod 1777 "$KNOWLEDGE_DIR"
    cp -a "$BUNDLE_DIR/docs/." "$KNOWLEDGE_DIR/"
    log "Docs imported: $(find "$KNOWLEDGE_DIR" -name '*.md' | wc -l) files"
}

# ── Step 5: Install project source ────────────────────────────────────────
install_source() {
    log "=== Step 5: Installing project source ==="
    sudo mkdir -p "$DEPLOY_DIR"
    sudo cp -a "$BUNDLE_DIR/source/." "$DEPLOY_DIR/"
    sudo chown -R "$USER:$USER" "$DEPLOY_DIR"
    chmod +x "$DEPLOY_DIR/scripts/"*.sh
    log "Source installed to $DEPLOY_DIR"
}

# ── Step 6: Build custom Ollama Modelfiles ─────────────────────────────────
build_models() {
    log "=== Step 6: Building custom Ollama models ==="

    # Start Ollama temporarily using the imported weights
    podman run --rm -d \
        --name ollama-build \
        -v ai-platform-ollama-models:/root/.ollama:z \
        -p 11434:11434 \
        -v "$DEPLOY_DIR/modelfiles":/modelfiles:ro,z \
        "$REGISTRY/ollama/ollama:latest" ollama serve

    local i=0
    until curl -sf http://127.0.0.1:11434/api/version &>/dev/null; do
        sleep 2; ((i++))
        [[ $i -gt 30 ]] && { podman stop ollama-build; die "Ollama timed out"; }
    done

    log "Building devops-expert..."
    podman exec ollama-build \
        ollama create devops-expert -f /modelfiles/Modelfile.devops-expert

    log "Building devops-reasoner..."
    podman exec ollama-build \
        ollama create devops-reasoner -f /modelfiles/Modelfile.devops-reasoner

    podman stop ollama-build
    log "Custom models built."
}

# ── Step 7: Generate certificates ─────────────────────────────────────────
gen_certs() {
    local cert_dir="$DEPLOY_DIR/certs"
    if [[ -f "$cert_dir/server.crt" ]]; then
        log "Certs already exist — skipping generation"
        return
    fi
    log "=== Step 7: Generating certificates ==="
    chmod +x "$DEPLOY_DIR/scripts/setup.sh"
    # Call only the cert generation step — no internet needed
    cd "$DEPLOY_DIR" && bash scripts/setup.sh certs
}

# ── Step 8: Start the platform ─────────────────────────────────────────────
start_platform() {
    log "=== Step 8: Starting platform ==="
    cd "$DEPLOY_DIR"

    # Use --airgapped flag: skips image builds and model pulls (already done)
    KNOWLEDGE_BASE_DIR="$KNOWLEDGE_DIR" \
    podman-compose \
        -f compose/compose.yml \
        -f compose/compose.override.podman.yml \
        up -d

    log ""
    log "Waiting for health checks..."
    sleep 10

    podman ps --pod --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"
}

# ── Summary ────────────────────────────────────────────────────────────────
summary() {
    local cert_dir="$DEPLOY_DIR/certs"
    log ""
    log "═══════════════════════════════════════════════════════════"
    log "  AI Platform deployed successfully"
    log "═══════════════════════════════════════════════════════════"
    log ""
    log "  Verify:"
    log "    curl -k --cacert $cert_dir/ca.crt \\"
    log "         --cert $cert_dir/client.crt \\"
    log "         --key  $cert_dir/client.key \\"
    log "         https://ai-platform.internal/healthz"
    log ""
    log "  Router status:"
    log "    curl -sf http://localhost:8080/healthz | python3 -m json.tool"
    log ""
    log "  Watch routing decisions:"
    log "    podman logs -f ai-router"
    log ""
    log "  Deliver developer certs:"
    log "    $cert_dir/client.crt"
    log "    $cert_dir/client.key"
    log "    $cert_dir/ca.crt"
    log ""
}

# ── Main ───────────────────────────────────────────────────────────────────
preflight
start_registry
load_images
import_models
import_docs
install_source
build_models
gen_certs
start_platform
summary
