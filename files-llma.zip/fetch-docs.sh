#!/usr/bin/env bash
# knowledge-seed/fetch-docs.sh
#
# Downloads official K8s, Docker, and Podman reference documentation
# into /opt/ai-platform/knowledge-base/ so the RAG ingestion engine
# has authoritative content to index on first boot.
#
# Run this ONCE on a machine with internet access before going airgapped,
# or run it on the jumpbox before the network is cut.
#
# Usage:
#   chmod +x fetch-docs.sh
#   ./fetch-docs.sh
#   # Then copy /opt/ai-platform/knowledge-base/ to your airgapped server

set -euo pipefail

OUTDIR="${1:-/opt/ai-platform/knowledge-base}"
mkdir -p "$OUTDIR"

log()  { echo "[$(date +%H:%M:%S)] $*"; }
fetch() {
    local url="$1" out="$2"
    if [[ -f "$out" ]]; then
        log "SKIP (exists): $(basename "$out")"
        return
    fi
    log "FETCH: $(basename "$out")"
    curl -fsSL --retry 3 --retry-delay 2 -o "$out" "$url" \
        || { log "WARN: failed to fetch $url — skipping"; rm -f "$out"; }
}

# ── Kubernetes ────────────────────────────────────────────────────────────────
log "=== Kubernetes reference docs ==="

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/overview/what-is-kubernetes.md" \
      "$OUTDIR/k8s-what-is-kubernetes.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/workloads/pods/pod-lifecycle.md" \
      "$OUTDIR/k8s-pod-lifecycle.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/workloads/controllers/deployment.md" \
      "$OUTDIR/k8s-deployments.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/workloads/controllers/statefulset.md" \
      "$OUTDIR/k8s-statefulsets.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/workloads/controllers/daemonset.md" \
      "$OUTDIR/k8s-daemonsets.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/services-networking/service.md" \
      "$OUTDIR/k8s-services.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/services-networking/ingress.md" \
      "$OUTDIR/k8s-ingress.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/services-networking/network-policies.md" \
      "$OUTDIR/k8s-network-policies.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/storage/persistent-volumes.md" \
      "$OUTDIR/k8s-persistent-volumes.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/storage/storage-classes.md" \
      "$OUTDIR/k8s-storage-classes.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/configuration/configmap.md" \
      "$OUTDIR/k8s-configmaps.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/configuration/secret.md" \
      "$OUTDIR/k8s-secrets.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/policy/resource-quotas.md" \
      "$OUTDIR/k8s-resource-quotas.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/policy/limit-range.md" \
      "$OUTDIR/k8s-limit-range.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/scheduling-eviction/pod-priority-preemption.md" \
      "$OUTDIR/k8s-pod-priority.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/scheduling-eviction/node-pressure-eviction.md" \
      "$OUTDIR/k8s-node-pressure-eviction.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/security/rbac-good-practices.md" \
      "$OUTDIR/k8s-rbac-good-practices.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/concepts/security/pod-security-standards.md" \
      "$OUTDIR/k8s-pod-security-standards.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/tasks/debug/debug-application/debug-pods.md" \
      "$OUTDIR/k8s-debug-pods.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/tasks/debug/debug-cluster/resource-metrics-pipeline.md" \
      "$OUTDIR/k8s-metrics-pipeline.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/tasks/administer-cluster/manage-resources/memory-default-namespace.md" \
      "$OUTDIR/k8s-memory-defaults.md"

fetch "https://raw.githubusercontent.com/kubernetes/website/main/content/en/docs/reference/kubectl/cheatsheet.md" \
      "$OUTDIR/k8s-kubectl-cheatsheet.md"

# ── Docker ────────────────────────────────────────────────────────────────────
log "=== Docker reference docs ==="

fetch "https://raw.githubusercontent.com/docker/docs/main/content/get-started/docker-overview.md" \
      "$OUTDIR/docker-overview.md"

fetch "https://raw.githubusercontent.com/docker/docs/main/content/reference/dockerfile.md" \
      "$OUTDIR/docker-dockerfile-reference.md"

fetch "https://raw.githubusercontent.com/docker/docs/main/content/compose/compose-file/_index.md" \
      "$OUTDIR/docker-compose-spec.md"

fetch "https://raw.githubusercontent.com/docker/docs/main/content/build/building/best-practices.md" \
      "$OUTDIR/docker-build-best-practices.md"

fetch "https://raw.githubusercontent.com/docker/docs/main/content/engine/security/rootless.md" \
      "$OUTDIR/docker-rootless.md"

fetch "https://raw.githubusercontent.com/docker/docs/main/content/engine/network/_index.md" \
      "$OUTDIR/docker-networking.md"

fetch "https://raw.githubusercontent.com/docker/docs/main/content/storage/volumes.md" \
      "$OUTDIR/docker-volumes.md"

# ── Podman ────────────────────────────────────────────────────────────────────
log "=== Podman reference docs ==="

fetch "https://raw.githubusercontent.com/containers/podman/main/docs/tutorials/rootless_tutorial.md" \
      "$OUTDIR/podman-rootless-tutorial.md"

fetch "https://raw.githubusercontent.com/containers/podman/main/docs/tutorials/podman-for-docker-users.md" \
      "$OUTDIR/podman-for-docker-users.md"

fetch "https://raw.githubusercontent.com/containers/podman/main/docs/tutorials/basic_networking.md" \
      "$OUTDIR/podman-networking.md"

fetch "https://raw.githubusercontent.com/containers/podman/main/docs/tutorials/systemd_integration.md" \
      "$OUTDIR/podman-systemd-integration.md"

fetch "https://raw.githubusercontent.com/containers/podman/main/docs/tutorials/podman-generate-kube.md" \
      "$OUTDIR/podman-generate-kube.md"

# ── Helm ──────────────────────────────────────────────────────────────────────
log "=== Helm reference docs ==="

fetch "https://raw.githubusercontent.com/helm/helm-www/main/content/en/docs/chart_template_guide/getting_started.md" \
      "$OUTDIR/helm-chart-template-guide.md"

fetch "https://raw.githubusercontent.com/helm/helm-www/main/content/en/docs/topics/charts.md" \
      "$OUTDIR/helm-charts.md"

fetch "https://raw.githubusercontent.com/helm/helm-www/main/content/en/docs/topics/chart_best_practices/values.md" \
      "$OUTDIR/helm-values-best-practices.md"

# ── Summary ───────────────────────────────────────────────────────────────────
log ""
log "Done. Files written to: $OUTDIR"
log "Total files: $(find "$OUTDIR" -name '*.md' | wc -l)"
log ""
log "Next: copy this directory to your airgapped server at"
log "  /opt/ai-platform/knowledge-base/"
log "The RAG ingestion engine will index everything within 15 seconds of startup."
