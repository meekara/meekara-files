# Transfer Guide: Jumpbox → Airgapped AI Server

## Overview

```
JUMPBOX (internet)              AIRGAPPED AI SERVER
4 core / 16 GB                  48 core / 196 GB
──────────────────              ─────────────────────────────
01-download.sh                  (receive via scp)
  ↓                                    ↓
02-bundle.sh ──── scp ──────► 03-deploy.sh
  creates                        loads images
  ai-platform-YYYYMMDD.tar.gz    imports models
  + sha256 manifest              starts platform
```

---

## Step-by-step

### On the jumpbox (internet)

```bash
# 1. Clone / copy the project to jumpbox
git clone <your-repo> airgapped-ai-platform
cd airgapped-ai-platform

# 2. Download everything (~40 GB, takes 30–90 min depending on connection)
chmod +x jumpbox/01-download.sh
./jumpbox/01-download.sh

# 3. Bundle into a single archive + SHA-256 manifest
chmod +x jumpbox/02-bundle.sh
./jumpbox/02-bundle.sh

# For USB transfer or slow links, split into 4 GB chunks:
# ./jumpbox/02-bundle.sh --split
```

This produces:
```
ai-platform-20260628-1045.tar.gz    (~38 GB compressed)
ai-platform-20260628-1045.sha256    (integrity manifest)
```

### Transfer to AI server

```bash
# Set your AI server hostname or IP
AI_SERVER=192.168.10.50   # or hostname
AI_USER=admin

# Create transfer directory on AI server first
ssh ${AI_USER}@${AI_SERVER} 'sudo mkdir -p /opt/ai-platform/transfer && \
    sudo chown ${USER}:${USER} /opt/ai-platform/transfer'

# Copy archive + manifest
scp ai-platform-*.tar.gz \
    ai-platform-*.sha256 \
    ${AI_USER}@${AI_SERVER}:/opt/ai-platform/transfer/

# If you used --split, copy parts instead:
# scp ai-platform-*-*.part ai-platform-*.sha256 \
#     ${AI_USER}@${AI_SERVER}:/opt/ai-platform/transfer/
```

### On the AI server (airgapped)

```bash
cd /opt/ai-platform/transfer

# If split: reassemble first
# cat ai-platform-20260628-1045-*.part > ai-platform-20260628-1045.tar.gz

# 1. Verify integrity
sha256sum -c ai-platform-20260628-1045.sha256
# All files should show: OK

# 2. Extract
tar -xzf ai-platform-20260628-1045.tar.gz
# Produces: ./bundle/

# 3. Deploy (loads images, imports models, starts platform)
chmod +x bundle/source/jumpbox/03-deploy.sh
./bundle/source/jumpbox/03-deploy.sh ./bundle
```

---

## Bundle contents

```
bundle/
├── images/                      (~3 GB)
│   ├── ollama.tar                Ollama inference engine
│   ├── chromadb.tar              Vector database
│   ├── nginx.tar                 mTLS gateway
│   ├── elia.tar                  Terminal UI client
│   ├── python-rag-processor.tar  PDF/YAML ingestion (built on jumpbox)
│   └── ai-router.tar             Model router (built on jumpbox)
│
├── models/                      (~37 GB)
│   └── manifests/ blobs/         Ollama GGUF model weights
│       ├── qwen2.5-coder:32b     ~18 GB — DevOps/K8s code
│       ├── qwen3:32b             ~18 GB — reasoning / RCA
│       └── nomic-embed-text      ~274 MB — RAG embeddings
│
├── pip/                         (~200 MB)
│   ├── rag/                      Wheels for python-rag-processor
│   └── router/                   Wheels for ai-router
│
├── docs/                        (~5 MB)
│   └── *.md                      K8s, Docker, Podman, Helm reference docs
│
└── source/                      (~1 MB)
    └── airgapped-ai-platform/    Full project source
```

---

## Disk requirements

| Location | Required | Notes |
|---|---|---|
| Jumpbox (download) | ~42 GB | Temporary — can delete after scp |
| Transfer path | ~38 GB | Compressed archive |
| AI server (extracted) | ~42 GB | `bundle/` directory |
| AI server (deployed) | ~38 GB | Podman volumes + app |
| AI server (total) | ~80 GB | During install; bundle can be deleted after |

---

## Troubleshooting

| Problem | Fix |
|---|---|
| `01-download.sh` fails on model pull | Re-run — Ollama pull is resumable |
| `scp` too slow | Use `--split` in `02-bundle.sh` and transfer via USB |
| Integrity check fails | Re-transfer the corrupted file; check with `sha256sum -c` |
| Registry won't start on AI server | Check port 5000 is free: `ss -tlnp \| grep 5000` |
| Image load fails | Check available disk: `df -h /`; need ~10 GB free during load |
| Ollama models not found | Check volume path: `podman volume inspect ai-platform-ollama-models` |
