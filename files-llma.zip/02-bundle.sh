#!/usr/bin/env bash
# jumpbox/02-bundle.sh
# ─────────────────────────────────────────────────────────────────────────────
# Run on the JUMPBOX after 01-download.sh completes.
# Packages the bundle/ directory into a single compressed archive,
# generates a SHA-256 manifest for integrity verification on the AI server,
# and shows the scp command to run.
#
# Usage:
#   ./02-bundle.sh
#   ./02-bundle.sh --split  # split into 4 GB parts (for USB transfer)
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

BUNDLE_DIR="$(pwd)/bundle"
TIMESTAMP="$(date +%Y%m%d-%H%M)"
ARCHIVE_NAME="ai-platform-${TIMESTAMP}.tar.gz"
MANIFEST_NAME="ai-platform-${TIMESTAMP}.sha256"
SPLIT_SIZE="4G"  # for USB / split transfer

log() { echo "[$(date +%H:%M:%S)] $*"; }
die() { echo "ERROR: $*" >&2; exit 1; }

[[ -d "$BUNDLE_DIR" ]] || die "bundle/ not found — run 01-download.sh first"

SPLIT_MODE=false
for arg in "$@"; do [[ "$arg" == "--split" ]] && SPLIT_MODE=true; done

# ── Check bundle is complete ───────────────────────────────────────────────
log "Verifying bundle contents..."
for required in \
    "$BUNDLE_DIR/images/ollama.tar" \
    "$BUNDLE_DIR/images/chromadb.tar" \
    "$BUNDLE_DIR/images/nginx.tar" \
    "$BUNDLE_DIR/images/elia.tar" \
    "$BUNDLE_DIR/images/python-rag-processor.tar" \
    "$BUNDLE_DIR/images/ai-router.tar" \
    "$BUNDLE_DIR/models" \
    "$BUNDLE_DIR/source/compose/compose.yml"
do
    [[ -e "$required" ]] || die "Missing: $required — re-run 01-download.sh"
done
log "Bundle contents verified."

# ── Create archive ─────────────────────────────────────────────────────────
log "Creating archive: $ARCHIVE_NAME"
log "  (This may take several minutes for ~40 GB)"

tar -czf "$ARCHIVE_NAME" \
    --checkpoint=5000 \
    --checkpoint-action=echo="%T" \
    -C "$(dirname "$BUNDLE_DIR")" \
    "$(basename "$BUNDLE_DIR")"

ARCHIVE_SIZE="$(du -sh "$ARCHIVE_NAME" | cut -f1)"
log "Archive created: $ARCHIVE_NAME ($ARCHIVE_SIZE)"

# ── SHA-256 manifest ───────────────────────────────────────────────────────
log "Generating SHA-256 manifest..."
sha256sum "$ARCHIVE_NAME" > "$MANIFEST_NAME"

# Also hash individual files for granular verification on the AI server
(
    cd "$BUNDLE_DIR"
    find . -type f | sort | xargs sha256sum
) >> "$MANIFEST_NAME"

log "Manifest written: $MANIFEST_NAME"

# ── Optional split ─────────────────────────────────────────────────────────
if $SPLIT_MODE; then
    log "Splitting into ${SPLIT_SIZE} parts..."
    split -b "$SPLIT_SIZE" -d \
        --suffix-length=3 \
        --additional-suffix=".part" \
        "$ARCHIVE_NAME" "${ARCHIVE_NAME%.tar.gz}-"
    log "Parts created:"
    ls -lh "${ARCHIVE_NAME%.tar.gz}-"*.part
    log ""
    log "To reassemble on AI server:"
    log "  cat ai-platform-${TIMESTAMP}-*.part > $ARCHIVE_NAME"
    log "  sha256sum -c $MANIFEST_NAME"
fi

# ── Transfer instructions ──────────────────────────────────────────────────
AI_SERVER="${AI_SERVER:-ai-server}"
REMOTE_PATH="${REMOTE_PATH:-/opt/ai-platform/transfer}"

log ""
log "═══════════════════════════════════════════════════════════"
log "  Bundle ready"
log "═══════════════════════════════════════════════════════════"
log ""
log "  Archive:  $ARCHIVE_NAME  ($ARCHIVE_SIZE)"
log "  Manifest: $MANIFEST_NAME"
log ""
log "  Transfer to AI server:"
log ""
if $SPLIT_MODE; then
log "  # Copy parts + manifest"
log "  scp ai-platform-${TIMESTAMP}-*.part \\"
log "      $MANIFEST_NAME \\"
log "      \${USER}@${AI_SERVER}:${REMOTE_PATH}/"
log ""
log "  # Reassemble on AI server"
log "  ssh \${USER}@${AI_SERVER} \\"
log "    'cat ${REMOTE_PATH}/ai-platform-${TIMESTAMP}-*.part > \\"
log "         ${REMOTE_PATH}/${ARCHIVE_NAME}'"
else
log "  scp $ARCHIVE_NAME $MANIFEST_NAME \\"
log "      \${USER}@${AI_SERVER}:${REMOTE_PATH}/"
fi
log ""
log "  Then on AI server:"
log "    cd ${REMOTE_PATH}"
log "    sha256sum -c $MANIFEST_NAME           # verify integrity"
log "    tar -xzf $ARCHIVE_NAME               # extract"
log "    cd bundle/source && ./scripts/setup.sh install --airgapped"
log ""
log "  Next step: run 03-deploy.sh on the AI server"
log ""
