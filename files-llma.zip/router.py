#!/usr/bin/env python3
"""
router.py — AI Model Router
────────────────────────────
Sits between Nginx and Ollama. Receives every chat/generate request,
classifies the prompt using a fast keyword + heuristic pass, then
optionally confirms with a lightweight LLM classifier call, and finally
rewrites the `model` field before forwarding to Ollama.

Clients send requests with model set to the sentinel value "auto"
(or any value — the router always overrides it). They never need to
know which model was selected.

Routing logic:
  devops-reasoner  ← complex diagnosis, RCA, incidents, "why", multi-step
  devops-expert    ← everything else (YAML, manifests, commands, how-to)
  nomic-embed-text ← never routed here; embedding is internal only

Architecture:
  Elia/client → Nginx (:443 mTLS) → Router (:8080) → Ollama (:11434)

The router is intentionally simple — no state, no auth (Nginx handles that),
no database. Pure HTTP proxy with model injection.
"""

import json
import logging
import os
import re
import time
from typing import AsyncIterator

import httpx
from fastapi import FastAPI, Request, Response
from fastapi.responses import StreamingResponse

# ── Config ────────────────────────────────────────────────────────────────────
OLLAMA_HOST       = os.getenv("OLLAMA_HOST",       "http://127.0.0.1:11434")
EXPERT_MODEL      = os.getenv("EXPERT_MODEL",      "devops-expert")
REASONER_MODEL    = os.getenv("REASONER_MODEL",    "devops-reasoner")
CLASSIFIER_MODEL  = os.getenv("CLASSIFIER_MODEL",  "devops-expert")  # fast, small call
LOG_LEVEL         = os.getenv("LOG_LEVEL",         "INFO")
# Set to "fast" (keyword-only) or "llm" (keyword + LLM confirmation)
ROUTING_MODE      = os.getenv("ROUTING_MODE",      "llm")

logging.basicConfig(level=LOG_LEVEL, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("router")

app = FastAPI(title="DevOps AI Model Router", version="1.0.0")

# ── Keyword classifier ────────────────────────────────────────────────────────
# These patterns route to devops-reasoner (complex reasoning / diagnosis).
# Everything else goes to devops-expert (fast, deterministic config work).

REASONER_PATTERNS = [
    # Diagnostic questions
    r"\bwhy\b", r"\bwhy is\b", r"\bwhy does\b", r"\bwhy (would|did|won't|can't)\b",
    r"\broot cause\b", r"\brca\b",
    r"\bwhat('s| is) (wrong|happening|causing|broken)\b",
    r"\bfigure out\b", r"\bdiagnos\b", r"\btroubleshoot\b",
    # Incident / failure language
    r"\bcrash(ing|ed)?\b", r"\boom.?kill\b", r"\beviction\b", r"\bpending\b.*\bpod\b",
    r"\bfailing\b", r"\bnot (starting|running|working|responding|healthy)\b",
    r"\bimage pull\b", r"\bcrashloopback\b", r"\bcreatecontainererror\b",
    r"\btimeout\b", r"\blatency\b", r"\bperformance\b.*\bissue\b",
    r"\b(high|increased|spike)\b.*\b(cpu|memory|load|latency)\b",
    r"\boutage\b", r"\bincident\b", r"\bpostmortem\b",
    # Log / event analysis
    r"\banalyze\b.*\blog\b", r"\blog.*\banalyz\b",
    r"\bcheck.*\blog\b", r"\bthis log\b", r"\bthese logs\b",
    r"\bevent\b.*\bkubernetes\b", r"\bdescribe.*\bpod\b",
    # Architecture / planning
    r"\bshould (i|we)\b", r"\bbest (way|approach|practice|strategy)\b",
    r"\btrade.?off\b", r"\bcompare\b", r"\bversus\b|\bvs\b",
    r"\barchitect\b", r"\bdesign\b.*\bcluster\b",
    r"\bcapacity plan\b", r"\bscaling strat\b",
    # Multi-step / complex
    r"\bstep.by.step\b", r"\bwalk me through\b", r"\bexplain.*complex\b",
    r"\bunderstand\b.*\bhow\b", r"\bhow does.*actually work\b",
]

REASONER_RE = re.compile("|".join(REASONER_PATTERNS), re.IGNORECASE)

# Quick positive signals for expert (used only for logging clarity)
EXPERT_PATTERNS = [
    r"\bwrite\b.*\b(yaml|manifest|dockerfile|compose|helm|playbook)\b",
    r"\bgenerate\b.*\b(yaml|manifest|config)\b",
    r"\b(create|add|update|fix|patch)\b.*\b(deployment|service|ingress|configmap|secret)\b",
    r"\bkubectl\b", r"\bpodman\b", r"\bdocker\b.*\bcommand\b",
    r"\bwhat (command|flag|option)\b",
    r"\bshow me.*\b(example|snippet|template)\b",
]
EXPERT_RE = re.compile("|".join(EXPERT_PATTERNS), re.IGNORECASE)


def extract_prompt(body: dict) -> str:
    """Pull the user-facing text from either /api/chat or /api/generate body."""
    # /api/chat  → messages[-1].content (last user message)
    if "messages" in body:
        for msg in reversed(body["messages"]):
            if msg.get("role") == "user":
                content = msg.get("content", "")
                return content if isinstance(content, str) else str(content)
    # /api/generate → prompt field
    return body.get("prompt", "")


def keyword_classify(prompt: str) -> str:
    """Fast keyword-based classification. Returns model name."""
    if REASONER_RE.search(prompt):
        return REASONER_MODEL
    return EXPERT_MODEL


async def llm_classify(prompt: str, client: httpx.AsyncClient) -> str:
    """
    Single-shot LLM classification call to devops-expert (fast, non-streaming).
    Returns model name. Falls back to keyword result on any error.
    """
    classification_prompt = f"""Classify this DevOps question into exactly one category.
Reply with ONLY the word REASON or EXPERT — nothing else.

REASON = complex diagnosis, incident investigation, root cause analysis,
         log/event analysis, "why is X happening", architecture trade-offs,
         multi-step troubleshooting, performance investigation.

EXPERT = writing YAML/manifests/Dockerfiles, kubectl/podman/docker commands,
         config generation, how-to questions with known answers, quick lookups.

Question: {prompt[:400]}

Category:"""

    try:
        resp = await client.post(
            f"{OLLAMA_HOST}/api/generate",
            json={
                "model": CLASSIFIER_MODEL,
                "prompt": classification_prompt,
                "stream": False,
                "options": {"temperature": 0, "num_predict": 4},
            },
            timeout=10.0,
        )
        resp.raise_for_status()
        answer = resp.json().get("response", "").strip().upper()
        if "REASON" in answer:
            return REASONER_MODEL
        if "EXPERT" in answer:
            return EXPERT_MODEL
    except Exception as exc:
        log.warning("LLM classifier failed (%s) — falling back to keywords", exc)

    return keyword_classify(prompt)


async def select_model(prompt: str, client: httpx.AsyncClient) -> tuple[str, str]:
    """
    Returns (model_name, method) where method is 'keyword' or 'llm'.
    Always uses keywords first; if ROUTING_MODE=llm, confirms with LLM.
    """
    kw_model = keyword_classify(prompt)

    if ROUTING_MODE == "llm":
        llm_model = await llm_classify(prompt, client)
        # LLM result wins; log when they disagree
        if llm_model != kw_model:
            log.info("Router: keyword=%s llm=%s → using llm", kw_model, llm_model)
        return llm_model, "llm"

    return kw_model, "keyword"


# ── Streaming proxy helpers ───────────────────────────────────────────────────

async def stream_ollama(
    client: httpx.AsyncClient, method: str, path: str, body: dict
) -> AsyncIterator[bytes]:
    """Streams the Ollama response chunk by chunk back to the client."""
    async with client.stream(
        method,
        f"{OLLAMA_HOST}{path}",
        json=body,
        timeout=None,
    ) as resp:
        async for chunk in resp.aiter_bytes():
            yield chunk


# ── Routes ────────────────────────────────────────────────────────────────────

@app.post("/api/chat")
@app.post("/api/generate")
async def route_request(request: Request) -> Response:
    path = request.url.path
    raw  = await request.body()

    try:
        body = json.loads(raw)
    except json.JSONDecodeError:
        return Response(content="Invalid JSON", status_code=400)

    prompt = extract_prompt(body)
    if not prompt.strip():
        # No prompt — pass through unchanged (e.g. keep-alive pings)
        async with httpx.AsyncClient() as client:
            resp = await client.request(
                request.method,
                f"{OLLAMA_HOST}{path}",
                content=raw,
                headers={"Content-Type": "application/json"},
                timeout=60,
            )
            return Response(content=resp.content, status_code=resp.status_code,
                            media_type="application/json")

    t0 = time.monotonic()
    async with httpx.AsyncClient() as client:
        chosen_model, method = await select_model(prompt, client)

    elapsed = (time.monotonic() - t0) * 1000
    original_model = body.get("model", "auto")

    log.info(
        "ROUTE [%.0fms | %s] %r → %s  (client requested: %s)",
        elapsed, method, prompt[:80], chosen_model, original_model,
    )

    # Rewrite the model field — client never needs to know
    body["model"] = chosen_model

    streaming = body.get("stream", True)

    async with httpx.AsyncClient() as client:
        if streaming:
            return StreamingResponse(
                stream_ollama(client, "POST", path, body),
                media_type="application/x-ndjson",
                headers={"X-Routed-Model": chosen_model, "X-Route-Method": method},
            )
        else:
            resp = await client.post(
                f"{OLLAMA_HOST}{path}",
                json=body,
                timeout=300,
            )
            return Response(
                content=resp.content,
                status_code=resp.status_code,
                media_type="application/json",
                headers={"X-Routed-Model": chosen_model, "X-Route-Method": method},
            )


# ── Passthrough for all other Ollama endpoints ────────────────────────────────
# /api/tags, /api/version, /api/show, etc. — forward unchanged

@app.api_route("/{path:path}", methods=["GET", "POST", "DELETE"])
async def passthrough(request: Request, path: str) -> Response:
    async with httpx.AsyncClient() as client:
        resp = await client.request(
            method=request.method,
            url=f"{OLLAMA_HOST}/{path}",
            content=await request.body(),
            headers={"Content-Type": request.headers.get("content-type", "application/json")},
            params=dict(request.query_params),
            timeout=60,
        )
    return Response(content=resp.content, status_code=resp.status_code,
                    media_type=resp.headers.get("content-type", "application/json"))


# ── Health ────────────────────────────────────────────────────────────────────

@app.get("/healthz")
async def health() -> dict:
    return {"status": "ok", "routing_mode": ROUTING_MODE,
            "expert": EXPERT_MODEL, "reasoner": REASONER_MODEL}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080, log_level=LOG_LEVEL.lower())
