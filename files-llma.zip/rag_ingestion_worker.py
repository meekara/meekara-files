#!/usr/bin/env python3
"""
rag_ingestion_worker.py
Watches /incoming for PDFs, YAML manifests, and text files.
Chunks them, embeds via Ollama, and pushes vectors into ChromaDB.
Already-indexed files are skipped (tracked by SHA-256 hash).
"""

import hashlib, logging, os, time
from pathlib import Path

import chromadb, httpx, yaml

try:
    import pypdf
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False

CHROMA_HOST    = os.getenv("CHROMA_HOST",    "127.0.0.1")
CHROMA_PORT    = int(os.getenv("CHROMA_PORT", "8000"))
OLLAMA_HOST    = os.getenv("OLLAMA_HOST",    "http://127.0.0.1:11434")
EMBED_MODEL    = os.getenv("EMBED_MODEL",    "nomic-embed-text")
CHUNK_SIZE     = int(os.getenv("CHUNK_SIZE",  "512"))
CHUNK_OVERLAP  = int(os.getenv("CHUNK_OVERLAP", "64"))
WATCH_INTERVAL = int(os.getenv("WATCH_INTERVAL", "15"))
INCOMING_DIR   = Path(os.getenv("INCOMING_DIR", "/incoming"))
COLLECTION     = "platform-knowledge"

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("rag")


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def extract(path):
    s = path.suffix.lower()
    if s == ".pdf":
        if not PDF_SUPPORT:
            return ""
        parts = []
        with open(path, "rb") as f:
            for page in pypdf.PdfReader(f).pages:
                parts.append(page.extract_text() or "")
        return "\n".join(parts)
    if s in {".yaml", ".yml"}:
        with open(path) as f:
            docs = list(yaml.safe_load_all(f))
        return "\n---\n".join(yaml.dump(d) for d in docs if d)
    return path.read_text(errors="replace")


def chunk(text):
    parts, start = [], 0
    while start < len(text):
        parts.append(text[start:start + CHUNK_SIZE].strip())
        start += CHUNK_SIZE - CHUNK_OVERLAP
    return [p for p in parts if len(p) > 30]


def embed(texts):
    out = []
    for t in texts:
        r = httpx.post(f"{OLLAMA_HOST}/api/embeddings",
                       json={"model": EMBED_MODEL, "prompt": t}, timeout=60)
        r.raise_for_status()
        out.append(r.json()["embedding"])
    return out


def ingest(col, path):
    h = sha256(path)
    if col.get(where={"file_hash": {"$eq": h}}, limit=1)["ids"]:
        log.info("SKIP  %s", path.name)
        return
    log.info("INDEX %s", path.name)
    text = extract(path)
    if not text.strip():
        return
    chunks = chunk(text)
    embeddings = embed(chunks)
    col.add(
        ids=[f"{h}::{i}" for i in range(len(chunks))],
        embeddings=embeddings,
        documents=chunks,
        metadatas=[{"source": path.name, "file_hash": h, "chunk_idx": i}
                   for i in range(len(chunks))],
    )
    log.info("  → %d vectors stored", len(chunks))


def main():
    log.info("RAG worker starting — inbox: %s  poll: %ds", INCOMING_DIR, WATCH_INTERVAL)
    client = chromadb.HttpClient(host=CHROMA_HOST, port=CHROMA_PORT)
    col = client.get_or_create_collection(COLLECTION, metadata={"hnsw:space": "cosine"})
    log.info("Collection '%s' ready (%d vectors)", COLLECTION, col.count())

    supported = {".pdf", ".yaml", ".yml", ".txt", ".md"}
    while True:
        for path in sorted(INCOMING_DIR.rglob("*")):
            if path.is_file() and path.suffix.lower() in supported:
                try:
                    ingest(col, path)
                except Exception as e:
                    log.error("ERROR %s: %s", path.name, e)
        time.sleep(WATCH_INTERVAL)


if __name__ == "__main__":
    main()
