# Installation Guide

## Prerequisites

- Kubernetes cluster (v1.20+)
- Helm 3.x installed
- `kubectl` configured with cluster access
- NFS server accessible from all cluster nodes
- Container registry (internal) for pulling the image

## Step 1: Configure values.yaml

Copy the default values and customize for your environment:

```bash
cp values.yaml my-values.yaml
```

Edit `my-values.yaml` and set at minimum:

```yaml
nfs:
  server: <nfs-server-address>
  path: <nfs-export-path>
```

### Optional Security Settings

```yaml
auth:
  apiKey: <generate-a-random-secret>

targetNamespaces:
  - default
  - production
```

- `auth.apiKey`: When set, all API requests require the `X-API-Key` header. Leave empty for open access.
- `targetNamespaces`: When set, restricts the dashboard to only these namespaces. Leave empty to allow all namespaces.

## Step 2: Build the Container Image

**This step requires internet access.** Build the image in an environment with internet access and push it to an internal registry reachable from the airgapped cluster.

```bash
docker build -t <internal-registry>/k8s-process-dump:latest .
docker push <internal-registry>/k8s-process-dump:latest
```

Then update `values.yaml`:

```yaml
image:
  repository: <internal-registry>/k8s-process-dump
  tag: latest
```

### Runtime Network Behavior

This application makes **no outbound internet connections** at runtime. The only network traffic is:
- Kubernetes API calls (in-cluster, localhost)
- NFS mount (Kubernetes-managed volume mount)
- LDAP server (only if LDAP auth is configured; connects to your LDAP, not the internet)

## Step 3: Install the Helm Chart

```bash
helm install process-dump ./k8s-process-dump \
  -f my-values.yaml \
  --set nfs.server=<nfs-server> \
  --set nfs.path=<nfs-export-path> \
  --set nfs.mountPath=/mnt/dumps
```

### With API Key Authentication

```bash
helm install process-dump ./k8s-process-dump \
  -f my-values.yaml \
  --set nfs.server=<nfs-server> \
  --set nfs.path=<nfs-export-path> \
  --set auth.apiKey=<your-secret-key>
```

### With Namespace Restriction

```bash
helm install process-dump ./k8s-process-dump \
  -f my-values.yaml \
  --set nfs.server=<nfs-server> \
  --set nfs.path=<nfs-export-path> \
  --set targetNamespaces[0]=default \
  --set targetNamespaces[1]=production
```

### With LDAP Authentication

```bash
helm install process-dump ./k8s-process-dump \
  -f my-values.yaml \
  --set nfs.server=<nfs-server> \
  --set nfs.path=<nfs-export-path> \
  --set auth.ldap.enabled=true \
  --set auth.ldap.server=ldap://ldap.example.com \
  --set auth.ldap.bindDN=cn=admin,dc=example,dc=com \
  --set auth.ldap.bindPassword=<bind-password> \
  --set auth.ldap.baseDN=ou=users,dc=example,dc=com \
  --set auth.ldap.groupDN=cn=process-dump-users,ou=groups,dc=example,dc=com
```

Or edit `my-values.yaml`:

```yaml
auth:
  ldap:
    enabled: true
    server: "ldap://ldap.example.com"
    bindDN: "cn=admin,dc=example,dc=com"
    bindPassword: "<bind-password>"
    baseDN: "ou=users,dc=example,dc=com"
    userFilter: "(uid={username})"
    groupDN: "cn=process-dump-users,ou=groups,dc=example,dc=com"
    groupMemberAttr: "member"
```

When LDAP is enabled, users authenticate via browser Basic Auth popup and must be members of the configured LDAP group.

### Combined API Key + LDAP

Both methods can be enabled simultaneously. Requests are accepted if either authentication succeeds:

```bash
helm install process-dump ./k8s-process-dump \
  -f my-values.yaml \
  --set nfs.server=<nfs-server> \
  --set nfs.path=<nfs-export-path> \
  --set auth.apiKey=<your-secret-key> \
  --set auth.ldap.enabled=true \
  ...
```

### Session Timeout

The dashboard enforces a **1-hour session timeout**. A countdown timer is displayed in the top-right corner of the UI. When the session expires, the page reloads and the user must re-authenticate.

## Step 4: Verify the Installation

Check that the DaemonSet is running on all nodes:

```bash
kubectl get daemonset -l app.kubernetes.io/name=k8s-process-dump
```

Check pod logs:

```bash
kubectl logs -l app.kubernetes.io/name=k8s-process-dump --tail=20
```

Verify the service is accessible:

```bash
kubectl get svc -l app.kubernetes.io/name=k8s-process-dump
```

## Step 5: Access the Dashboard

If using `ClusterIP` (default), access from within the cluster:

```bash
kubectl port-forward svc/process-dump-k8s-process-dump 8080:80
```

Then open `http://localhost:8080` in a browser.

If using `NodePort` or `LoadBalancer`, use the assigned external IP/port.

### Authenticated Access

If `auth.apiKey` is set, include the header in all requests:

```bash
curl -H "X-API-Key: <your-secret-key>" http://localhost:8080/
```

## Step 6: Generate a Process Dump

1. Open the dashboard in a browser.
2. Select a namespace from the sidebar.
3. Select a deployment from the sidebar.
4. Select a pod from the sidebar.
5. The host PID will auto-resolve.
6. Choose the runtime (Java, Python, or .NET).
7. Enter a filename (e.g., `heap.hprof`).
8. Click **Generate Dump**.
9. Check the status area for success or error messages.

## Step 7: Download Dump Files

After a dump is generated, it appears in the **Dump Files** table. Click **Download** to save the file.

## Uninstallation

```bash
helm uninstall process-dump
```

## Troubleshooting

### Pod fails to start

Check pod events:

```bash
kubectl describe pod -l app.kubernetes.io/name=k8s-process-dump
```

Common issues:
- NFS server unreachable from nodes
- Missing `SYS_PTRACE` capability (check pod security policies)
- `readOnlyRootFilesystem` prevents writing to `/tmp`

### Dump generation fails

Check pod logs for error details:

```bash
kubectl logs -l app.kubernetes.io/name=k8s-process-dump
```

Common issues:
- Target pod PID not found (pod may have restarted)
- Unsupported runtime selected
- NFS mount not writable

### 401 Unauthorized

If `auth.apiKey` is set, ensure the `X-API-Key` header is included in requests.