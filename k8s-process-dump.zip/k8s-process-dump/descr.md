Here is a comprehensive project description specification designed to feed into an AI coding agent (such as Cursor, Windsurf, or Copilot) to build, validate, and verify the entire project end-to-end.

---

# 📋 Project Specification: Kubernetes Unprivileged Container Process Dump Agent

## 1. Executive Summary & Goal

The objective is to build a production-grade, secure **Kubernetes Helm Chart** that deploys a privileged **Node-Level DaemonSet** with an embedded **FastAPI Web UI Dashboard**.

The tool enables Cluster Administrators to generate runtime process memory/heap dumps (Java, Python, .NET) for unprivileged application pods running across target namespaces without injecting sidecars, modifying application deployments, or adding debug containers. Generated dumps are streamed directly into a shared **NFS mount**. All container images must be **distroless**-based using multi-stage builds on Debian 12.

---

## 2. Technical Architecture & Constraints

### Architecture Overview

1. 
**Target Namespace Applications**: Run with strict security contexts (`unprivileged`, no extra capabilities, no debug sidecars).


2. **DaemonSet Agent**:
* Runs as a privileged DaemonSet on every node.


* Shares the host PID namespace (`hostPID: true`) to access host-level process paths (`/proc`).


* Connects to a target NFS share where memory dump files are stored and served.




3. **Execution Mechanism**:
* Uses `nsenter` and native CLI debug toolsets (`jcmd`, `py-spy`, `dotnet-dump`) to interact directly with target processes via their Host PIDs.
* For dump operations, uses `nsenter -t <pid> --mount -- <tool> <args>` to enter the target pod's mount namespace and run the specific debug tool. Arbitrary shell commands are blocked by a whitelist of allowed tools.








---




4. **Security & Image Constraints**:
* Base image **MUST** be `gcr.io/distroless/python3-debian12:debug`.


* 
**NO** shell execution (`shell=False`) inside the application backend. All system processes must be executed directly as command arrays via Python's `subprocess.run()`.





---

## 3. Project File Directory Structure

```text
k8s-process-dump/
├── Dockerfile
├── app.py
├── Chart.yaml
├── descr.md
├── values.yaml
└── templates/
    ├── _helpers.tpl
    ├── daemonset.yaml
    ├── networkpolicy.yaml
    ├── rbac.yaml
    └── service.yaml

```

---

## 4. Component Technical Specifications

### A. Container Image (`Dockerfile`)

* 
**Stage 1 (Builder)**: `debian:12-slim` 


* Install dependencies: `openjdk-17-jdk-headless`, `python3`, `python3-pip`, `python3-venv`, `python3-py-spy`, `gdb`, `util-linux`, `procps`, `curl`, `ca-certificates`, `wget`.


* Download and install Microsoft .NET 8 SDK and the `dotnet-dump` global tool.


* Create a virtual environment (`/opt/venv`) and install `fastapi`, `uvicorn`, `pydantic`.




* 
**Stage 2 (Runtime)**: `gcr.io/distroless/python3-debian12:debug` 


* Copy virtual environment, JDK home binaries (`/usr/lib/jvm/java-17-openjdk-amd64`), .NET utilities, and binaries (`py-spy`, `gdb`, `nsenter`, `pgrep`, `kill`) from the builder stage.


* Copy dynamic shared system libraries (`/lib/x86_64-linux-gnu`, `/usr/lib/x86_64-linux-gnu`).


* Set `ENTRYPOINT` directly to: `["/opt/venv/bin/uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8080"]`.





### B. Agent Backend & Web Dashboard (`app.py`)

* 
**Framework**: FastAPI serving HTML dashboard frontend and REST endpoints.


* **Endpoints**:
1. 
`GET /`: Serves single-page HTML/CSS/JS web dashboard.


2. 
`POST /api/v1/dump`: Accepts JSON payload `{ "pid": int, "runtime": str, "filename": str }`.


* 
**Java**: Runs `["/usr/bin/nsenter", "-t", pid, "-m", "-p", "--", "jcmd", "1", "GC.heap_dump", target_path]`.


* 
**Python**: Runs `["/usr/bin/py-spy", "dump", "--pid", pid, "-o", target_path]`.


* 
**.NET**: Runs `["/usr/local/bin/dotnet-dump", "collect", "-p", pid, "-o", target_path]`.


* **Node.js**: Removed — the distroless runtime image does not include the `node` binary, making this runtime non-functional.


* Executed strictly via `subprocess.run(cmd, capture_output=True, text=True, shell=False)`.




3. 
`GET /api/v1/files`: Returns list of dump files in `DUMP_DIR` (defaults to `/mnt/dumps`).


4. 
`GET /api/v1/files/download/{filename}`: Downloads dump file directly from `DUMP_DIR` via `FileResponse`.

5. 
`GET /api/v1/namespaces`: Returns a list of Kubernetes namespaces by calling `kubectl get namespaces`.

6. 
`GET /api/v1/namespaces/{namespace}/deployments`: Returns a list of deployment names in the given namespace by calling `kubectl get deployments -n {namespace}`.

7. 
`GET /api/v1/namespaces/{namespace}/deployments/{deployment}/pods`: Returns a list of pod names belonging to the given deployment in the specified namespace by calling `kubectl get pods -n {namespace} -l app={deployment}`.

8. 
`POST /api/v1/namespaces/{namespace}/pods/{pod}/exec`: Accepts JSON payload `{ "command": str }`. Only allows whitelisted debug tools (`jcmd`, `py-spy`, `dotnet-dump`). Resolves the pod's host PID via `pgrep -f podIP=<pod_ip>`, then uses `nsenter -t <pid> --mount -- <tool> <args>` to execute the command within the target pod's mount namespace. Returns `{ "output": str, "returncode": int }`.








---

### C. Helm Chart Specs

1. **`values.yaml`**:
* Image details (`repository`, `tag`, `pullPolicy`).
* `auth.apiKey` — optional API key for dashboard/API authentication. Set via `API_KEY` env var.
* `targetNamespaces` — optional list of allowed namespaces. When set, restricts dashboard to only these namespaces.
* `webUi.port: 8080`, `webUi.service.type: ClusterIP`, `webUi.service.port: 80`.
* `nfs.server`, `nfs.path`, `nfs.mountPath: "/mnt/dumps"`.
* ServiceAccount and RBAC configuration toggles.




2. **`templates/daemonset.yaml`**:
* Spec: `hostPID: true`.
* SecurityContext: `privileged: true`, `allowPrivilegeEscalation: false`, `readOnlyRootFilesystem: true`.
* Drops all Linux capabilities and only adds `SYS_PTRACE`.
* Environment variables: `DUMP_DIR`, `API_KEY` (optional), `TARGET_NAMESPACES` (optional comma-separated allowlist).
* Volume Mounts:
* NFS direct volume mounted at `.Values.nfs.mountPath`.
* `tmp` emptyDir for temporary files.
* Liveness and readiness probes on `/health`.
* Resource limits: 256Mi/512Mi memory, 250m/500m CPU.






3. **`templates/rbac.yaml`**:
* ClusterRole granting `get`, `list`, `watch` on `pods` and `nodes`.


* ClusterRoleBinding mapping ServiceAccount to the ClusterRole.




4. **`templates/service.yaml`**:
* Exposes HTTP service mapping target port `8080` to service port `80`.





---

## 5. UI Mockup

### Dashboard Layout

The web dashboard is a single-page application served at `GET /` with a two-column layout featuring a three-level hierarchy selector on the right side:

```
┌────────────────────────────────────────────────────┬──────────────────────────┐
│  📋 Process Dump Dashboard                          │  Namespace ▼             │
│                                                      │                          │
│  ┌────────────────────────────────────────────┐   │  ● default              │
│  │  Generate New Dump                           │   │  ● production           │
│  │                                                │   │  ○ staging              │
│  │  Namespace:     [default ▼]               │   │  ○ monitoring           │
│  │  Deployment:    [app-server ▼]           │   │                          │
│  │  Pod:           [app-server-7b8f ▼]     │   │  Deployments in        │
│  │                                                │   │  "default":            │
│  │  Process ID (PID):  [_______________]      │   │    ● app-server         │
│  │  Runtime:          [Java ▼]                │   │    ○ worker             │
│  │  Filename:         [_______________]      │   │                          │
│  │                                                │   │  Pods in "app-server": │
│  │              [ Generate Dump ]             │   │    ▸ app-server-7b8f   │
│  └────────────────────────────────────────────┘   │    ▸ app-server-9c2d   │
│                                                      │                          │
│  ┌────────────────────────────────────────────┐   │                          │
│  │  Status:                                      │   │                          │
│  │  (message displayed after submit)           │   │                          │
│  └────────────────────────────────────────────┘   │                          │
│                                                      │                          │
│  ┌────────────────────────────────────────────┐   │                          │
│  │  Dump Files                                   │   │                          │
│  │                                                │   │                          │
│  │  Filename              │ Action             │   │                          │
│  │  ──────────────────── │ ────────────────── │   │                          │
│  │  heap_dump.hprof      │ [Download]         │   │                          │
│  │  profile.json         │ [Download]         │   │                          │
│  │                                                │   │                          │
│  └────────────────────────────────────────────┘   │                          │
└────────────────────────────────────────────────────┴──────────────────────────┘

### UI Components

1. **Namespace Selector** (right sidebar, top):
   - Dropdown populated from `GET /api/v1/namespaces`.
   - The first namespace is selected by default.
   - Clicking a namespace highlights it and loads deployments for that namespace.

2. **Deployment Selector** (right sidebar, below namespace):
   - Dropdown populated from `GET /api/v1/namespaces/{namespace}/deployments`.
   - Updates when a different namespace is selected.
   - Clicking a deployment highlights it and loads pods for that deployment.

3. **Pod Selector** (right sidebar, below deployment):
   - Dropdown populated from `GET /api/v1/namespaces/{namespace}/deployments/{deployment}/pods`.
   - Updates when a different deployment is selected.
   - The selected pod's name is displayed.

4. **Dump Generation Form** (left panel):
   - Namespace, Deployment, and Pod dropdowns are pre-populated based on the right sidebar selection.
   - Runtime selector with four options: `Java`, `Python`, `.NET`, `Node.js`.
   - Filename input and Generate Dump button.
   - Sends `POST /api/v1/dump`.

5. **Dump Files Table** (left panel, below form):
   - Refresh button and file listing with download links.

6. **Status Area**:
   - Shows success or error feedback after dump generation.

### UI Behavior

- On page load, the namespace list is fetched and the first namespace is selected.
- Deployments and pods are loaded progressively based on the selected namespace and deployment.
- Submitting the form sends a JSON POST request and displays the result in the status area.
- The refresh button reloads the file list from the server.
- Download links trigger a browser file download for the selected dump file.

### Color Scheme

| Element       | Background  | Text Color  | Border       |
|---------------|-------------|-------------|--------------|
| Page          | `#f5f5f5`   | `#333`      | —            |
| Cards         | `#fff`      | `#333`      | `#ddd`       |
| Primary Button| `#007bff`   | `#fff`      | —            |
| Success       | `#d4edda`   | `#155724`   | `#c3e6cb`    |
| Error         | `#f8d7da`   | `#721c24`   | `#f5c6cb`    |

---

## 6. Security Mitigations

The DaemonSet pod runs with `privileged: true` and `hostPID: true`, which allows it to use `nsenter` to enter target pod namespaces. To address the security risk of arbitrary command execution inside target pods, the following mitigations are applied:

### 1. Restricted Command Execution (Item 1)

The `POST /api/v1/namespaces/{namespace}/pods/{pod}/exec` endpoint only allows a whitelist of specific debug tools:

| Tool | Allowed Action |
|------|---------------|
| `jcmd` | `GC.heap_dump` only |
| `py-spy` | `dump` only |
| `dotnet-dump` | `collect` only |

Arbitrary shell commands are blocked. The endpoint resolves the target pod's PID via `pgrep` and constructs the exact command array for the allowed tool, with no shell interpretation.

### 2. Dropped Linux Capabilities (Item 2)

The DaemonSet container drops all Linux capabilities and only adds `SYS_PTRACE`, which is required for `nsenter` and debug tools to attach to target processes:

```yaml
securityContext:
  privileged: true
  capabilities:
    drop: ["ALL"]
    add: ["SYS_PTRACE"]
```

### 3. API Key Authentication (Item 3)

The dashboard and all API endpoints are protected by an optional API key. When `auth.apiKey` is set in `values.yaml` or the `API_KEY` environment variable is configured, requests must include the `X-API-Key` header. Requests without a valid key receive `401 Unauthorized`. When unset, the dashboard is accessible without authentication (backward compatible).

### 4. LDAP Authentication (Item 4)

When `auth.ldap.enabled` is set to `true` in `values.yaml`, the dashboard requires LDAP authentication via browser Basic Auth. The LDAP server is configured with the following settings:

| Setting | Env Var | Description |
|---------|---------|-------------|
| `server` | `LDAP_SERVER` | LDAP server URL (e.g., `ldap://ldap.example.com`) |
| `bindDN` | `LDAP_BIND_DN` | Service account DN for binding and searching |
| `bindPassword` | `LDAP_BIND_PASSWORD` | Service account password |
| `baseDN` | `LDAP_BASE_DN` | Base DN for user search |
| `userFilter` | `LDAP_USER_FILTER` | LDAP filter for user lookup (default: `(uid={username})`) |
| `groupDN` | `LDAP_GROUP_DN` | DN of the LDAP group that is allowed access |
| `groupMemberAttr` | `LDAP_GROUP_MEMBER_ATTR` | Attribute that references group members (default: `member`) |

The authentication flow:
1. User provides credentials via browser Basic Auth popup.
2. App binds to LDAP with the service account.
3. App searches for the user by the configured filter.
4. App checks if the user is a member of the configured group.
5. App verifies the user's password by attempting to bind as the user.
6. If all checks pass, access is granted. Otherwise, `401 Unauthorized` is returned.

When LDAP is enabled alongside an API key, either authentication method is accepted.

### 5. Namespace Allowlist (Item 5)

The `targetNamespaces` configuration in `values.yaml` (or `TARGET_NAMESPACES` env var) restricts which namespaces the dashboard can discover and operate on. When set, only listed namespaces appear in the namespace selector and all namespace-scoped API calls are validated against the allowlist. When unset, all namespaces are accessible (backward compatible).

### 6. PID Verification (Item 6)

Before executing any dump operation, the resolved host PID is verified to be running using `os.kill(pid, 0)`. If the PID is not running, the operation returns a `404` error. This prevents stale or incorrect PID references.

### 7. Dump Timeout (Item 7)

The `POST /api/v1/dump` endpoint includes a 30-second timeout on subprocess execution. If a dump operation exceeds this limit, a `504 Gateway Timeout` response is returned. This prevents hanging operations from consuming resources indefinitely.

### 8. Security Headers (Item 8)

All HTTP responses include security headers:
- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY`
- `X-XSS-Protection: 1; mode=block`

These headers protect against MIME-type sniffing, clickjacking, and XSS attacks.

### 9. Minimal RBAC (Item 9)

The ServiceAccount is granted only the minimum RBAC permissions needed — `get`, `list`, `watch` on `pods`, `nodes`, `namespaces`, and `deployments`. No `pods/exec` permission is granted, which prevents `kubectl exec` from being used as an alternative attack vector. The `nsenter` approach operates at the host level, bypassing Kubernetes API authorization entirely, which is why the restricted command whitelist is critical.

---

## 8. Validation & Acceptance Criteria

When passing this prompt to an AI coding agent, request the agent to verify the output using the following tests:

1. **Distroless Integrity Test**:
* Run `docker run --rm <built-image> /bin/sh` and confirm it fails (proves no shell binaries are present).




2. **Subprocess Execution Test**:
* Verify that no `shell=True` arguments exist anywhere in `app.py`.




3. **Helm Lint & Dry-Run**:
* Execute `helm lint process-dump-chart`.


* Execute `helm template process-dump-chart/` and verify rendered manifests contain `hostPID: true`, privileged container flags, and valid volume definitions.
