import os
import re
import subprocess
import time
import base64
import uuid
from fastapi import FastAPI, Request, HTTPException, status
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse
from pydantic import BaseModel
from kubernetes import client, config

app = FastAPI()

DUMP_DIR = os.environ.get("DUMP_DIR", "/mnt/dumps")
API_KEY = os.environ.get("API_KEY", "").strip()
TARGET_NAMESPACES = set(
    ns.strip() for ns in os.environ.get("TARGET_NAMESPACES", "").split(",") if ns.strip()
)

LDAP_ENABLED = os.environ.get("LDAP_ENABLED", "").strip().lower() == "true"
LDAP_SERVER = os.environ.get("LDAP_SERVER", "").strip()
LDAP_BIND_DN = os.environ.get("LDAP_BIND_DN", "").strip()
LDAP_BIND_PASSWORD = os.environ.get("LDAP_BIND_PASSWORD", "").strip()
LDAP_BASE_DN = os.environ.get("LDAP_BASE_DN", "").strip()
LDAP_USER_FILTER = os.environ.get("LDAP_USER_FILTER", "(uid={username})").strip()
LDAP_GROUP_DN = os.environ.get("LDAP_GROUP_DN", "").strip()
LDAP_GROUP_MEMBER_ATTR = os.environ.get("LDAP_GROUP_MEMBER_ATTR", "member").strip()

try:
    from ldap3 import Server, Connection, ALL
    LDAP_AVAILABLE = True
except ImportError:
    LDAP_AVAILABLE = False

SESSIONS = {}
SESSION_TIMEOUT = 3600

ALLOWED_TOOLS = {
    "jcmd": ["/usr/bin/nsenter", "-t", "{pid}", "-m", "-p", "--", "jcmd", "1", "GC.heap_dump", "{target}"],
    "py-spy": ["/opt/venv/bin/py-spy", "dump", "--pid", "{pid}", "-o", "{target}"],
    "dotnet-dump": ["/usr/local/bin/dotnet-dump", "collect", "-p", "{pid}", "-o", "{target}"],
}

RUNTIME_COMMANDS = {
    "java": ["/usr/bin/nsenter", "-t", "{pid}", "-m", "-p", "--", "jcmd", "1", "GC.heap_dump", "{target}"],
    "python": ["/opt/venv/bin/py-spy", "dump", "--pid", "{pid}", "-o", "{target}"],
    "dotnet": ["/usr/local/bin/dotnet-dump", "collect", "-p", "{pid}", "-o", "{target}"],
}


NAMESPACE_PATTERN = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9._-]*$')

def validate_namespace(namespace: str) -> str:
    if not NAMESPACE_PATTERN.match(namespace):
        raise HTTPException(status_code=400, detail="Invalid namespace name")
    if TARGET_NAMESPACES and namespace not in TARGET_NAMESPACES:
        raise HTTPException(status_code=403, detail="Namespace not in target allowlist")
    return namespace

def verify_pid_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False

def validate_ldap_user(username: str, password: str) -> bool:
    if not LDAP_ENABLED or not LDAP_AVAILABLE:
        return False
    if not LDAP_SERVER or not LDAP_BIND_DN or not LDAP_BASE_DN or not LDAP_GROUP_DN:
        return False
    try:
        server = Server(LDAP_SERVER, get_info=ALL)
        conn = Connection(server, user=LDAP_BIND_DN, password=LDAP_BIND_PASSWORD, auto_bind=True)
        search_filter = LDAP_USER_FILTER.replace("{username}", username)
        conn.search(LDAP_BASE_DN, search_filter, attributes=["dn"])
        if not conn.entries:
            return False
        user_dn = str(conn.entries[0].entry_dn)
        conn.search(LDAP_GROUP_DN, f"({LDAP_GROUP_MEMBER_ATTR}={user_dn})")
        if not conn.entries:
            return False
        user_conn = Connection(server, user=user_dn, password=password, auto_bind=True)
        return user_conn.bind()
    except Exception:
        return False

def _get_session_key(request: Request) -> str | None:
    if API_KEY:
        provided = request.headers.get("X-API-Key", "")
        if provided:
            return f"apikey:{provided}"
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Basic "):
        try:
            decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
            username = decoded.split(":", 1)[0]
            return f"basic:{username}"
        except Exception:
            pass
    return None


def _check_session(request: Request) -> bool:
    session_key = _get_session_key(request)
    if not session_key:
        return False
    if session_key not in SESSIONS:
        return False
    if time.time() - SESSIONS[session_key]["created_at"] >= SESSION_TIMEOUT:
        del SESSIONS[session_key]
        return False
    return True


@app.middleware("http")
async def api_key_auth(request: Request, call_next):
    if request.url.path == "/health":
        return await call_next(request)

    if _check_session(request):
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        return response

    authenticated = False
    session_key = None

    if API_KEY:
        provided = request.headers.get("X-API-Key", "")
        if provided == API_KEY:
            authenticated = True
            session_key = f"apikey:{provided}"

    if not authenticated and LDAP_ENABLED:
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Basic "):
            try:
                decoded = base64.b64decode(auth_header[6:]).decode("utf-8")
                username, password = decoded.split(":", 1)
                if validate_ldap_user(username, password):
                    authenticated = True
                    session_key = f"basic:{username}"
            except Exception:
                pass

    if authenticated and session_key:
        SESSIONS[session_key] = {"created_at": time.time()}
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        return response

    if not API_KEY and not LDAP_ENABLED:
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        return response

    return JSONResponse(
        status_code=status.HTTP_401_UNAUTHORIZED,
        content={"detail": "Authentication required"}
    )


class DumpRequest(BaseModel):
    pid: int
    runtime: str
    filename: str


class ResolveRequest(BaseModel):
    namespace: str
    pod: str


class ExecRequest(BaseModel):
    tool: str


def validate_filename(name: str) -> str:
    if os.path.basename(name) != name:
        raise ValueError("filename must not contain path separators")
    return name


def validate_pid(pid: int) -> int:
    if pid < 1 or pid > 999999999:
        raise ValueError("PID out of valid range")
    return pid


def resolve_pod_pid(namespace: str, pod: str) -> str:
    if not app.state.k8s_core:
        raise RuntimeError("Kubernetes client not available. Check cluster connectivity or kubeconfig.")
    validate_namespace(namespace)
    pod_obj = app.state.k8s_core.read_namespaced_pod(pod, namespace)
    pod_ip = pod_obj.status.pod_ip
    if not pod_ip:
        raise RuntimeError("Pod IP not found")
    result = subprocess.run(
        ["pgrep", "-f", f"podIP={pod_ip}"],
        capture_output=True, text=True, shell=False,
    )
    if result.returncode != 0 or not result.stdout.strip():
        raise RuntimeError("Could not resolve pod PID on host")
    pid = result.stdout.strip().split()[0]
    if not verify_pid_running(int(pid)):
        raise RuntimeError("Resolved PID is not running")
    return pid


@app.on_event("startup")
def startup():
    app.state.k8s_core = None
    app.state.k8s_apps = None
    try:
        config.load_incluster_config()
        app.state.k8s_core = client.CoreV1Api()
        app.state.k8s_apps = client.AppsV1Api()
    except config.ConfigException:
        try:
            config.load_kube_config()
            app.state.k8s_core = client.CoreV1Api()
            app.state.k8s_apps = client.AppsV1Api()
        except config.ConfigException:
            pass


@app.get("/health")
async def health():
    k8s_status = "connected" if app.state.k8s_core else "unavailable"
    return {"status": "ok", "kubernetes": k8s_status}

@app.get("/", response_class=HTMLResponse)
async def index():
    html = HTML_PAGE.replace("{{ API_KEY }}", API_KEY if API_KEY else "")
    return HTMLResponse(content=html)


@app.post("/api/v1/dump")
async def create_dump(body: DumpRequest):
    pid = validate_pid(body.pid)
    if not verify_pid_running(pid):
        return JSONResponse(status_code=404, content={"error": "PID not found or not running"})
    filename = validate_filename(body.filename)
    target = os.path.join(DUMP_DIR, filename)
    pid_str = str(pid)

    template = RUNTIME_COMMANDS.get(body.runtime)
    if not template:
        return JSONResponse(status_code=400, content={"error": f"Unsupported runtime: {body.runtime}"})

    cmd = [a.replace("{pid}", pid_str).replace("{target}", target) for a in template]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, shell=False, timeout=30)
        if result.returncode != 0:
            return JSONResponse(status_code=500, content={"error": result.stderr})
        return JSONResponse(content={"status": "success", "filename": filename})
    except subprocess.TimeoutExpired:
        return JSONResponse(status_code=504, content={"error": "Dump timed out after 30s"})
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.post("/api/v1/resolve-pid")
async def resolve_pid(body: ResolveRequest):
    try:
        pid = resolve_pod_pid(body.namespace, body.pod)
        return JSONResponse(content={"pid": int(pid)})
    except Exception as e:
        return JSONResponse(status_code=404, content={"error": str(e)})


@app.get("/api/v1/files")
async def list_files():
    try:
        files = sorted(
            f for f in os.listdir(DUMP_DIR)
            if os.path.isfile(os.path.join(DUMP_DIR, f))
        )
        return JSONResponse(content=files)
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.get("/api/v1/files/download/{filename}")
async def download_file(filename: str):
    validate_filename(filename)
    path = os.path.join(DUMP_DIR, filename)
    if not os.path.isfile(path):
        return JSONResponse(status_code=404, content={"error": "File not found"})
    return FileResponse(path, filename=filename)


@app.get("/api/v1/namespaces")
async def list_namespaces():
    if not app.state.k8s_core:
        return JSONResponse(status_code=503, content={"error": "Kubernetes client not available. Check cluster connectivity or kubeconfig."})
    try:
        items = app.state.k8s_core.list_namespace()
        namespaces = [ns.metadata.name for ns in items.items]
        if TARGET_NAMESPACES:
            namespaces = [ns for ns in namespaces if ns in TARGET_NAMESPACES]
        return JSONResponse(content=namespaces)
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.get("/api/v1/namespaces/{namespace}/deployments")
async def list_deployments(namespace: str):
    if not app.state.k8s_apps:
        return JSONResponse(status_code=503, content={"error": "Kubernetes client not available. Check cluster connectivity or kubeconfig."})
    validate_namespace(namespace)
    try:
        items = app.state.k8s_apps.list_namespaced_deployment(namespace)
        return JSONResponse(content=[d.metadata.name for d in items.items])
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.get("/api/v1/namespaces/{namespace}/deployments/{deployment}/pods")
async def list_pods(namespace: str, deployment: str):
    if not app.state.k8s_core:
        return JSONResponse(status_code=503, content={"error": "Kubernetes client not available. Check cluster connectivity or kubeconfig."})
    validate_namespace(namespace)
    try:
        items = app.state.k8s_core.list_namespaced_pods(
            namespace, label_selector=f"app={deployment}"
        )
        return JSONResponse(content=[p.metadata.name for p in items.items])
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


@app.post("/api/v1/namespaces/{namespace}/pods/{pod}/exec")
async def exec_on_pod(namespace: str, pod: str, body: ExecRequest):
    validate_namespace(namespace)
    tool = body.tool.strip()
    if tool not in ALLOWED_TOOLS:
        return JSONResponse(
            status_code=403,
            content={"error": f"Tool not allowed. Allowed: {', '.join(ALLOWED_TOOLS)}"},
        )
    try:
        target_pid = resolve_pod_pid(namespace, pod)
        template = ALLOWED_TOOLS[tool]
        cmd = [
            a.replace("{pid}", target_pid).replace(
                "{target}", os.path.join(DUMP_DIR, f"dump_{target_pid}")
            )
            for a in template
        ]
        result = subprocess.run(cmd, capture_output=True, text=True, shell=False, timeout=30)
        return JSONResponse(
            content={
                "output": result.stdout if result.returncode == 0 else result.stderr,
                "returncode": result.returncode,
            }
        )
    except subprocess.TimeoutExpired:
        return JSONResponse(status_code=504, content={"error": "Command timed out after 30s"})
    except Exception as e:
        return JSONResponse(status_code=500, content={"error": str(e)})


HTML_PAGE = """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Process Dump Dashboard</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:sans-serif;margin:2rem;background:#f5f5f5;color:#333}
h1{margin-bottom:1.5rem;font-size:1.5rem}
.session-timer{position:fixed;top:1rem;right:1rem;background:#fff;border:1px solid #ddd;border-radius:8px;padding:.5rem 1rem;font-size:.85rem;box-shadow:0 2px 4px rgba(0,0,0,.1);z-index:100;display:flex;align-items:center;gap:.5rem}
.session-timer.warning{background:#fff3cd;border-color:#ffc107;color:#856404}
.session-timer.expired{background:#f8d7da;border-color:#dc3545;color:#721c24}
.session-timer .timer-value{font-weight:700;font-size:1rem}
.layout{display:flex;gap:1.5rem;align-items:flex-start}
.main{flex:1;min-width:0}
.sidebar{width:300px;flex-shrink:0}
.card{background:#fff;border:1px solid #ddd;border-radius:8px;padding:1.5rem;margin-bottom:1.5rem;box-shadow:0 2px 4px rgba(0,0,0,.05)}
.card h2{font-size:1.1rem;margin-bottom:1rem;color:#555}
label{display:block;margin:.75rem 0 .25rem;font-size:.9rem;font-weight:600;color:#555}
select,input{width:100%;padding:.5rem;border:1px solid #ccc;border-radius:4px;font-size:.95rem}
button{background:#007bff;color:#fff;border:none;padding:.75rem 1.5rem;border-radius:4px;cursor:pointer;font-size:.95rem;margin-top:1rem}
button:hover{background:#0056b3}
button.secondary{background:#6c757d}
button.secondary:hover{background:#545b62}
#status{margin-top:1rem;padding:.75rem;border-radius:4px;font-size:.9rem;display:none}
.success{background:#d4edda;color:#155724;border:1px solid #c3e6cb;display:block}
.error{background:#f8d7da;color:#721c24;border:1px solid #f5c6cb;display:block}
table{border-collapse:collapse;width:100%;margin-top:.5rem}
th,td{text-align:left;padding:.6rem .5rem;border-bottom:1px solid #ddd;font-size:.9rem}
th{background:#f8f9fa;font-weight:600}
a{color:#007bff;text-decoration:none}
.ns-list,.deploy-list,.pod-list{list-style:none;padding:0}
.ns-list li,.deploy-list li,.pod-list li{padding:.5rem .75rem;border:1px solid #ddd;border-radius:4px;margin-bottom:.25rem;cursor:pointer;font-size:.9rem;transition:background .15s}
.ns-list li:hover,.deploy-list li:hover,.pod-list li:hover{background:#e9ecef}
.ns-list li.active,.deploy-list li.active,.pod-list li.active{background:#007bff;color:#fff;border-color:#007bff}
</style>
</head>
<body>
<h1>Process Dump Dashboard</h1>
<div id="sessionTimer" class="session-timer">Session expires in: <span class="timer-value" id="sessionTimerValue">60:00</span></div>
<div class="layout">
<div class="main">
<div class="card">
<h2>Generate Dump</h2>
<form id="dumpForm">
<label for="nsSelect">Namespace:</label>
<select id="nsSelect" required><option value="">Loading...</option></select>
<label for="depSelect">Deployment:</label>
<select id="depSelect" required><option value="">-- Select namespace first --</option></select>
<label for="podSelect">Pod:</label>
<select id="podSelect" required><option value="">-- Select deployment first --</option></select>
<label for="pidInput">Host PID:</label>
<div style="display:flex;gap:.5rem">
<input type="number" id="pidInput" min="1" placeholder="Auto-resolved from pod" style="flex:1">
<button type="button" id="resolveBtn" class="secondary" style="margin-top:0;white-space:nowrap">Resolve</button>
</div>
<label for="runtimeSelect">Runtime:</label>
<select id="runtimeSelect" required>
<option value="java">Java</option>
<option value="python">Python</option>
<option value="dotnet">.NET</option>
</select>
<label for="filenameInput">Filename:</label>
<input type="text" id="filenameInput" placeholder="e.g. heap.hprof" required>
<button type="submit">Generate Dump</button>
</form>
<div id="status"></div>
</div>
<div class="card">
<h2>Dump Files <button id="refreshBtn" class="secondary">Refresh</button></h2>
<table><thead><tr><th>Filename</th><th>Action</th></tr></thead><tbody id="fileBody"></tbody></table>
</div>
</div>
<div class="sidebar">
<div class="card"><h2>Namespaces</h2><ul id="nsList" class="ns-list"></ul></div>
<div class="card"><h2>Deployments</h2><ul id="depList" class="deploy-list"><li style="color:#999">Select a namespace</li></ul></div>
<div class="card"><h2>Pods</h2><ul id="podList" class="pod-list"><li style="color:#999">Select a deployment</li></ul></div>
<div class="card">
<h2>Run Tool</h2>
<select id="toolSelect">
<option value="jcmd">jcmd</option>
<option value="py-spy">py-spy</option>
<option value="dotnet-dump">dotnet-dump</option>
</select>
<button id="execBtn">Execute</button>
<pre id="execOutput" style="background:#f8f9fa;padding:.5rem;border-radius:4px;margin-top:.5rem;font-size:.8rem;display:none;max-height:200px;overflow:auto"></pre>
</div>
</div>
</div>
<script>
var nsSelect=document.getElementById('nsSelect'),depSelect=document.getElementById('depSelect'),podSelect=document.getElementById('podSelect');
var nsList=document.getElementById('nsList'),depList=document.getElementById('depList'),podList=document.getElementById('podList');
var pidInput=document.getElementById('pidInput'),resolveBtn=document.getElementById('resolveBtn');
var filenameInput=document.getElementById('filenameInput'),runtimeSelect=document.getElementById('runtimeSelect');
var form=document.getElementById('dumpForm'),status=document.getElementById('status');
var refreshBtn=document.getElementById('refreshBtn'),fileBody=document.getElementById('fileBody');
var toolSelect=document.getElementById('toolSelect'),execBtn=document.getElementById('execBtn'),execOutput=document.getElementById('execOutput');
var API_KEY = "{{ API_KEY }}";

function showStatus(msg,cls){status.style.display='block';status.className=cls||'';status.textContent=msg}
function api(path,opts){opts=opts||{};opts.headers=opts.headers||{};if(API_KEY)opts.headers['X-API-Key']=API_KEY;return fetch(path,opts).then(function(r){if(r.status===401){document.getElementById('sessionTimer').textContent='Session expired';document.getElementById('sessionTimer').className='session-timer expired';setTimeout(function(){window.location.reload()},3000);return Promise.reject(new Error('Session expired'))}return r.json()})}

function loadNamespaces(){
 api('/api/v1/namespaces').then(function(data){
  if(data.error)return;
  nsList.innerHTML='';nsSelect.innerHTML='';
  data.forEach(function(ns,i){
   var li=document.createElement('li');li.textContent=ns;li.setAttribute('data-ns',ns);
   if(i===0)li.classList.add('active');
   nsList.appendChild(li);
   var o=document.createElement('option');o.value=ns;o.textContent=ns;nsSelect.appendChild(o);
  });
  if(data.length>0) selectNamespace(data[0]);
 });
}

function selectNamespace(ns){
 nsSelect.value=ns;
 depList.innerHTML='<li style="color:#999">Loading...</li>';depSelect.innerHTML='<option value="">Loading...</option>';
 podList.innerHTML='<li style="color:#999">--</li>';podSelect.innerHTML='<option value="">--</option>';
 pidInput.value='';
 api('/api/v1/namespaces/'+encodeURIComponent(ns)+'/deployments').then(function(data){
  if(data.error)return;
  depList.innerHTML='';depSelect.innerHTML='';
  data.forEach(function(d,i){
   var li=document.createElement('li');li.textContent=d;li.setAttribute('data-deploy',d);
   if(i===0)li.classList.add('active');
   depList.appendChild(li);
   var o=document.createElement('option');o.value=d;o.textContent=d;depSelect.appendChild(o);
  });
  if(data.length>0) selectDeployment(data[0]);
 });
}

function selectDeployment(dep){
 depSelect.value=dep;
 podList.innerHTML='<li style="color:#999">Loading...</li>';podSelect.innerHTML='<option value="">Loading...</option>';
 pidInput.value='';
 var ns=nsSelect.value;
 api('/api/v1/namespaces/'+encodeURIComponent(ns)+'/deployments/'+encodeURIComponent(dep)+'/pods').then(function(data){
  if(data.error)return;
  podList.innerHTML='';podSelect.innerHTML='';
  data.forEach(function(p,i){
   var li=document.createElement('li');li.textContent=p;li.setAttribute('data-pod',p);
   if(i===0)li.classList.add('active');
   podList.appendChild(li);
   var o=document.createElement('option');o.value=p;o.textContent=p;podSelect.appendChild(o);
  });
  if(data.length>0) selectPod(data[0]);
 });
}

function selectPod(pod){
 podSelect.value=pod;
 resolvePid();
}

function resolvePid(){
 var ns=nsSelect.value,dep=depSelect.value,pod=podSelect.value;
 if(!ns||!dep||!pod)return;
 pidInput.placeholder='Resolving...';
 api('/api/v1/resolve-pid',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({namespace:ns,pod:pod})}).then(function(data){
  if(data.pid){pidInput.value=data.pid;pidInput.placeholder=''}else{pidInput.value='';pidInput.placeholder='Not found'}
 });
}

nsList.addEventListener('click',function(e){
 var li=e.target.closest('li');if(!li)return;
 nsList.querySelectorAll('li').forEach(function(x){x.classList.remove('active')});
 li.classList.add('active');selectNamespace(li.getAttribute('data-ns'));
});
depList.addEventListener('click',function(e){
 var li=e.target.closest('li');if(!li)return;
 depList.querySelectorAll('li').forEach(function(x){x.classList.remove('active')});
 li.classList.add('active');selectDeployment(li.getAttribute('data-deploy'));
});
podList.addEventListener('click',function(e){
 var li=e.target.closest('li');if(!li)return;
 podList.querySelectorAll('li').forEach(function(x){x.classList.remove('active')});
 li.classList.add('active');selectPod(li.getAttribute('data-pod'));
});

resolveBtn.addEventListener('click',resolvePid);

form.addEventListener('submit',function(e){
 e.preventDefault();
 var pid=parseInt(pidInput.value,10);
 if(!pid||pid<1){showStatus('Enter or resolve a valid PID','error');return;}
 var filename=filenameInput.value.trim();
 if(!filename){showStatus('Enter a filename','error');return;}
 var runtime=runtimeSelect.value;
 showStatus('Generating '+runtime+' dump as '+filename+'...');
 api('/api/v1/dump',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({pid:pid,runtime:runtime,filename:filename})}).then(function(data){
  if(data.status==='success'){showStatus('Dump saved: '+filename,'success')}else{showStatus(data.error||'Failed','error')}
 });
});

refreshBtn.addEventListener('click',function(){
 api('/api/v1/files').then(function(data){
  fileBody.innerHTML='';
  if(!data||data.length===0){fileBody.innerHTML='<tr><td colspan="2" style="text-align:center;color:#999">No files</td></tr>';return}
  data.forEach(function(f){
   var tr=document.createElement('tr');
   tr.innerHTML='<td>'+f+'</td><td><a href="/api/v1/files/download/'+encodeURIComponent(f)+'">Download</a></td>';
   fileBody.appendChild(tr);
  });
 });
});

execBtn.addEventListener('click',function(){
 var ns=nsSelect.value,pod=podSelect.value,tool=toolSelect.value;
 if(!ns||!pod){execOutput.style.display='block';execOutput.textContent='Select a namespace and pod first';return}
 execOutput.style.display='block';execOutput.textContent='Running '+tool+'...';
 api('/api/v1/namespaces/'+encodeURIComponent(ns)+'/pods/'+encodeURIComponent(pod)+'/exec',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({tool:tool})}).then(function(data){
  execOutput.textContent=data.output||'(no output)';
 });
});

var SESSION_DURATION = 3600;
var sessionStart = Date.now();

function updateSessionTimer() {
    var elapsed = Math.floor((Date.now() - sessionStart) / 1000);
    var remaining = SESSION_DURATION - elapsed;
    if (remaining <= 0) {
        document.getElementById('sessionTimer').textContent = 'Session expired';
        document.getElementById('sessionTimer').className = 'session-timer expired';
        document.getElementById('sessionTimerValue').textContent = '00:00';
        setTimeout(function() {
            window.location.reload();
        }, 3000);
        return;
    }
    var minutes = Math.floor(remaining / 60);
    var seconds = remaining % 60;
    var minsStr = minutes < 10 ? '0' + minutes : minutes;
    var secsStr = seconds < 10 ? '0' + seconds : seconds;
    document.getElementById('sessionTimer').textContent = 'Session expires in:';
    document.getElementById('sessionTimerValue').textContent = minsStr + ':' + secsStr;
    
    if (remaining <= 300) {
        document.getElementById('sessionTimer').className = 'session-timer warning';
    }
}
setInterval(updateSessionTimer, 1000);
updateSessionTimer();

loadNamespaces();
refreshBtn.click();
</script>
</body>
</html>"""
