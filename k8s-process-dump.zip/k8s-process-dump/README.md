# k8s-process-dump

A production-grade Kubernetes Helm Chart that deploys a privileged Node-Level DaemonSet with an embedded FastAPI Web UI Dashboard for generating runtime process memory/heap dumps.

## Overview

This project enables Cluster Administrators to generate runtime process dumps (Java, Python, .NET) for unprivileged application pods across target namespaces — without injecting sidecars, modifying deployments, or adding debug containers. Generated dumps are streamed directly into a shared NFS mount.

## Architecture

- **DaemonSet Agent**: Runs privileged on every node with `hostPID: true`, accessing host-level `/proc` and target pod namespaces via `nsenter`.
- **FastAPI Backend**: Serves a single-page HTML dashboard and REST API endpoints for dump generation, file listing/download, and namespace/deployment/pod discovery via `kubectl`.
- **Container Image**: Multi-stage build on Debian 12; final image is distroless (`gcr.io/distroless/python3-debian12:debug`) with no shell binaries.
- **Security**: All Linux capabilities dropped except `SYS_PTRACE`; command execution restricted to a whitelist (`jcmd`, `py-spy`, `dotnet-dump`); no `shell=True` in subprocess calls; minimal RBAC (no `pods/exec` permission).

## Project Structure

```
k8s-process-dump/
├── Dockerfile              # Multi-stage build (builder + distroless runtime)
├── app.py                  # FastAPI backend + embedded HTML dashboard
├── Chart.yaml              # Helm chart metadata
├── descr.md                # Project specification for AI coding agents
├── values.yaml             # Helm configuration values
├── templates/
│   ├── _helpers.tpl        # Helm helper templates
│   ├── daemonset.yaml      # DaemonSet with hostPID, privileged, NFS/proc volumes
│   ├── networkpolicy.yaml  # NetworkPolicy restricting ingress to same namespace
│   ├── rbac.yaml           # ClusterRole + ClusterRoleBinding
│   └── service.yaml        # ClusterIP Service exposing the dashboard
```

## Key Features

- **Dump Generation**: `POST /api/v1/dump` — generates heap/process dumps for Java, Python, and .NET runtimes.
- **File Management**: `GET /api/v1/files` and `GET /api/v1/files/download/{filename}` — list and download dump files from the NFS mount.
- **Kubernetes Discovery**: Hierarchical API for namespaces, deployments, and pods via `kubectl`.
- **Restricted Exec**: `POST /api/v1/namespaces/{ns}/pods/{pod}/exec` — executes whitelisted debug tools inside target pod namespaces via `nsenter`.
- **Auth**: API key-based authentication via header `X-API-Key`, plus optional LDAP authentication with group validation via browser Basic Auth.

## Prerequisites

- Kubernetes cluster with NFS server accessible from nodes
- Helm 3.x
- kubectl configured with cluster access

## Installation

```bash
helm install process-dump ./k8s-process-dump \
  --set nfs.server=<nfs-server> \
  --set nfs.path=<nfs-export-path> \
  --set nfs.mountPath=/mnt/dumps
```

## Configuration

See `values.yaml` for configurable parameters including image repository/tag, NFS settings, web UI port/service type, RBAC toggles, API key authentication, LDAP authentication with group validation, and target namespace restrictions.

## Security

- **API Key Authentication**: Set `auth.apiKey` in `values.yaml` or `API_KEY` env var to restrict dashboard/API access. Unset by default (open access).
- **LDAP Authentication**: Set `auth.ldap.enabled: true` and configure LDAP server settings to validate users against an LDAP directory and restrict access to a specific group. When LDAP is enabled, browser Basic Auth popup is shown. API key auth also works alongside LDAP.
- **Namespace Allowlist**: Set `targetNamespaces` to restrict access to specific namespaces. Unset by default (all namespaces accessible).
- **Command Whitelist**: Only `jcmd`, `py-spy`, and `dotnet-dump` are permitted via the `/exec` endpoint.
- **No Shell Execution**: All subprocess calls use `shell=False` with static command arrays.
- **Minimal RBAC**: ServiceAccount has only `get`, `list`, `watch` on pods, nodes, namespaces, and deployments. No `pods/exec`.
- **Distroless Runtime**: Final image is shell-free, reducing attack surface.
- **Health Probes**: Liveness and readiness probes on `/health` ensure the agent is operational.
- **NetworkPolicy**: Ingress is restricted to the same namespace by default.