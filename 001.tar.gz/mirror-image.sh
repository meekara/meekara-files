#!/usr/bin/env bash
# mirror-image.sh — Copy Spegel image + Helm chart from ghcr.io to JFrog Artifactory.
#
# RUN THIS FROM AN INTERNET-CONNECTED BASTION that has skopeo installed.
# The air-gapped TKGI cluster itself does NOT need internet access.
#
# Works with both docker and podman as the container runtime.
#
# Usage:
#   ./mirror-image.sh
#   JFROG_URL=myjfrog.example.com JFROG_TOKEN=xxx ./mirror-image.sh
#
# Requirements: skopeo, jq, network access to both ghcr.io and JFrog

set -euo pipefail

# ─── Config (override via env vars) ──────────────────────────
JFROG_URL="${JFROG_URL:-jfrog.ykt.internal}"
JFROG_REPO="${JFROG_REPO:-ykt-docker-local}"
JFROG_USER="${JFROG_USER:-svc-k8s-push}"
JFROG_TOKEN="${JFROG_TOKEN:?ERROR: Set JFROG_TOKEN}"

SPEGEL_VERSION="${SPEGEL_VERSION:-v0.6.0}"
SPEGEL_CHART_VERSION="${SPEGEL_CHART_VERSION:-0.6.0}"

SOURCE_IMAGE="ghcr.io/spegel-org/spegel:${SPEGEL_VERSION}"
SOURCE_CHART="ghcr.io/spegel-org/helm-charts/spegel:${SPEGEL_CHART_VERSION}"

DEST_IMAGE="${JFROG_URL}/${JFROG_REPO}/spegel-org/spegel:${SPEGEL_VERSION}"
DEST_CHART="${JFROG_URL}/${JFROG_REPO}/spegel-org/helm-charts/spegel:${SPEGEL_CHART_VERSION}"

# ─── Detect container runtime ───────────────────────────────
RUNTIME="docker"
if command -v podman &>/dev/null && ! command -v docker &>/dev/null; then
    RUNTIME="podman"
fi

echo "=== Mirror Spegel to JFrog ==="
echo "Container runtime: ${RUNTIME}"
echo "Source image: ${SOURCE_IMAGE}"
echo "Dest image:   ${DEST_IMAGE}"
echo "Source chart: ${SOURCE_CHART}"
echo "Dest chart:   ${DEST_CHART}"
echo ""

# ─── Mirror container image ──────────────────────────────────
echo "--- Copying container image ---"
skopeo copy \
    --dest-creds="${JFROG_USER}:${JFROG_TOKEN}" \
    --dest-tls-verify=false \
    "docker://${SOURCE_IMAGE}" \
    "docker://${DEST_IMAGE}"
echo "  Image copied."

# ─── Mirror Helm chart (OCI artifact) ────────────────────────
echo ""
echo "--- Copying Helm chart ---"
skopeo copy \
    --dest-creds="${JFROG_USER}:${JFROG_TOKEN}" \
    --dest-tls-verify=false \
    "docker://${SOURCE_CHART}" \
    "docker://${DEST_CHART}"
echo "  Chart copied."

# ─── Verify ───────────────────────────────────────────────────
echo ""
echo "--- Verifying image in JFrog ---"
skopeo inspect \
    --creds="${JFROG_USER}:${JFROG_TOKEN}" \
    --tls-verify=false \
    "docker://${DEST_IMAGE}" | jq -r '.Name, .Digest'

echo ""
echo "=== Mirror complete ==="
echo ""
echo "Next: run ./deploy.sh from a machine with kubectl access to the TKGI cluster."
