#!/usr/bin/env bash
# deploy.sh — Spegel PoC deploy on an air-gapped TKGI cluster.
#
# Works with both docker and podman as the container runtime.
# On podman-only systems, helm OCI auth is configured automatically.
#
# Usage:
#   ./deploy.sh                       # deploy
#   ./deploy.sh --dry-run             # preview
#   ./deploy.sh --uninstall           # tear down
#
# Prerequisites:
#   - Spegel image + Helm chart already in JFrog (run mirror-image.sh first)
#   - helm >= 3.12, kubectl configured for TKGI cluster
#   - JFROG_USER and JFROG_TOKEN env vars set (for pull secret)

set -euo pipefail

POC_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NAMESPACE="spegel"
VALUES_FILE="${POC_DIR}/values-tkgi.yaml"
SPEGEL_VERSION="0.6.0"
DRY_RUN=""
UNINSTALL=false

# JFrog settings for pull secret
JFROG_URL="${JFROG_URL:-jfrog.ykt.internal}"
JFROG_USER="${JFROG_USER:-svc-k8s-pull}"
JFROG_TOKEN="${JFROG_TOKEN:-}"
JFROG_REPO="${JFROG_REPO:-ykt-docker-local}"

while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)     DRY_RUN="--dry-run --debug"; shift ;;
        --uninstall)   UNINSTALL=true; shift ;;
        --namespace)   NAMESPACE="$2"; shift 2 ;;
        --version)     SPEGEL_VERSION="$2"; shift 2 ;;
        *) echo "Usage: $0 [--dry-run] [--uninstall] [--namespace <ns>] [--version <ver>]"; exit 1 ;;
    esac
done

# ─── Uninstall ────────────────────────────────────────────────
if [[ "$UNINSTALL" == "true" ]]; then
    echo "=== Uninstalling Spegel ==="
    helm uninstall spegel --namespace "$NAMESPACE" 2>/dev/null || echo "No release found."
    kubectl delete namespace "$NAMESPACE" 2>/dev/null || true
    echo "Done."
    exit 0
fi

# ─── Detect container runtime ───────────────────────────────
RUNTIME="docker"
if command -v podman &>/dev/null && ! command -v docker &>/dev/null; then
    RUNTIME="podman"
fi

# ─── Configure helm OCI auth for podman ──────────────────────
# helm looks for ~/.docker/config.json by default.
# On podman-only systems, ensure the directory exists so helm can write/read creds.
HELM_REGISTRY_CONFIG=""
if [[ "$RUNTIME" == "podman" ]]; then
    mkdir -p "${HOME}/.docker"
    if [[ ! -f "${HOME}/.docker/config.json" ]]; then
        echo '{}' > "${HOME}/.docker/config.json"
    fi
    HELM_REGISTRY_CONFIG="--registry-config ${HOME}/.docker/config.json"
fi

echo "╔═══════════════════════════════════════════════╗"
echo "║  Spegel P2P Mirror — TKGI Air-Gapped PoC     ║"
echo "╠═══════════════════════════════════════════════╣"
echo "║  Namespace:   ${NAMESPACE}"
echo "║  Values:      ${VALUES_FILE}"
echo "║  Version:     ${SPEGEL_VERSION}"
echo "║  JFrog:       ${JFROG_URL}"
echo "║  Runtime:     ${RUNTIME}"
echo "║  Dry run:     ${DRY_RUN:-no}"
echo "╚═══════════════════════════════════════════════╝"
echo ""

# ─── Pre-flight ───────────────────────────────────────────────
echo "--- Pre-flight ---"

for cmd in helm kubectl; do
    if ! command -v "$cmd" &>/dev/null; then
        echo "ERROR: ${cmd} not found in PATH"
        exit 1
    fi
done

if ! kubectl cluster-info &>/dev/null; then
    echo "ERROR: Cannot reach Kubernetes cluster. Check your kubeconfig."
    exit 1
fi

NODE_COUNT=$(kubectl get nodes --no-headers 2>/dev/null | wc -l)
echo "Cluster reachable — ${NODE_COUNT} nodes"

# ─── Create namespace + pull secret ──────────────────────────
echo ""
echo "--- Namespace & Pull Secret ---"

kubectl create namespace "$NAMESPACE" 2>/dev/null || echo "Namespace '${NAMESPACE}' already exists."

if [[ -n "$JFROG_TOKEN" ]]; then
    echo "Creating JFrog pull secret..."
    kubectl -n "$NAMESPACE" create secret docker-registry jfrog-pull-secret \
        --docker-server="$JFROG_URL" \
        --docker-username="$JFROG_USER" \
        --docker-password="$JFROG_TOKEN" \
        --dry-run=client -o yaml | kubectl apply -f -
    echo "  Pull secret 'jfrog-pull-secret' ready."
else
    echo "WARNING: JFROG_TOKEN not set. Assuming pull secret 'jfrog-pull-secret' already exists."
fi

# ─── Helm login to JFrog for chart pull ──────────────────────
echo ""
echo "--- Helm Registry Login ---"

if [[ -n "$JFROG_TOKEN" ]]; then
    helm registry login "$JFROG_URL" \
        --username "$JFROG_USER" \
        --password "$JFROG_TOKEN" \
        --insecure \
        $HELM_REGISTRY_CONFIG 2>/dev/null || echo "WARNING: Helm registry login failed. Chart may not pull."
else
    echo "WARNING: JFROG_TOKEN not set. Assuming helm registry already logged in."
fi

# ─── Deploy from JFrog OCI chart ──────────────────────────────
echo ""
echo "--- Deploying Spegel from JFrog ---"

helm upgrade --install spegel \
    "oci://${JFROG_URL}/${JFROG_REPO}/spegel-org/helm-charts/spegel" \
    --version "$SPEGEL_VERSION" \
    --namespace "$NAMESPACE" \
    --values "$VALUES_FILE" \
    $HELM_REGISTRY_CONFIG \
    $DRY_RUN

# ─── Post-deploy ─────────────────────────────────────────────
if [[ -z "$DRY_RUN" ]]; then
    echo ""
    echo "--- Waiting for DaemonSet (up to 120s) ---"
    if kubectl -n "$NAMESPACE" rollout status daemonset/spegel --timeout=120s; then
        echo ""
        echo "--- Spegel Pods ---"
        kubectl -n "$NAMESPACE" get pods -o wide
        echo ""
        echo "--- DaemonSet ---"
        kubectl -n "$NAMESPACE" get daemonset spegel
    else
        echo ""
        echo "WARNING: DaemonSet did not fully roll out."
        echo "Check: kubectl -n ${NAMESPACE} get pods -o wide"
        echo "       kubectl -n ${NAMESPACE} describe ds spegel"
        echo "       kubectl -n ${NAMESPACE} logs -l app.kubernetes.io/name=spegel --tail=30"
    fi
fi

echo ""
echo "=== Done ==="
echo ""
echo "Next:"
echo "  Verify:    ./verify.sh"
echo "  Logs:      kubectl -n ${NAMESPACE} logs -l app.kubernetes.io/name=spegel --tail=20"
echo "  Metrics:   kubectl -n ${NAMESPACE} port-forward <pod> 8080:8080"
echo "  Uninstall: $0 --uninstall"
